import json
from decimal import Decimal
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum, Count, F, Q, ProtectedError
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db import transaction
from django.views.decorators.http import require_POST
from django.utils import timezone
from datetime import datetime, timedelta
from django.template.loader import render_to_string
try:
    from xhtml2pdf import pisa
except Exception:  # entorno sin deps PDF completas: se importa lazy al generar
    pisa = None
from io import BytesIO
from .models import (
    Producto, Categoria, Venta, DetalleVenta, PerfilUsuario, Empleado, Turno, Gasto, EntradaProducto, RetiroDonacion, InventarioDiario, MovimientoInventario, Deuda, Deudor, AbonoDeuda, MostradorEstado,
    fmt_cantidad_unidad, ArqueoTurno, ConteoCiego, ConteoCiegoLinea,
    DENOMINACIONES_CUP, DENOMINACIONES_CUP_VALOR,
)
from .forms import ProductoForm, CategoriaForm, EmpleadoForm, PresentacionFormSet


def ahora_servidor():
    return datetime.now()


# ============================================================
# AUTENTICACION
# ============================================================

def login_view(request):
    if request.user.is_authenticated:
        return redirect('core:redireccion_rol')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('core:redireccion_rol')
        else:
            return render(request, 'core/login.html', {'error': 'Usuario o contrasena incorrectos.'})
    return render(request, 'core/login.html')


def logout_view(request):
    logout(request)
    return redirect('core:login')


@login_required
def redireccion_rol(request):
    try:
        perfil = request.user.perfil
        if perfil.es_admin:
            return redirect('core:dashboard')
        else:
            return redirect('core:pos')
    except PerfilUsuario.DoesNotExist:
        return redirect('core:dashboard')


def requiere_admin(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('core:login')
        try:
            if not request.user.perfil.es_admin:
                return redirect('core:pos')
        except PerfilUsuario.DoesNotExist:
            pass
        return view_func(request, *args, **kwargs)
    wrapper.__name__ = view_func.__name__
    wrapper.__doc__ = view_func.__doc__
    return wrapper


# ============================================================
# DASHBOARD
# ============================================================

@requiere_admin
def dashboard(request):
    from datetime import timedelta
    from django.utils import timezone
    from django.conf import settings
    ahora = timezone.make_aware(ahora_servidor().replace(hour=0, minute=0, second=0, microsecond=0))
    inicio_dia = ahora
    fin_dia = inicio_dia + timedelta(days=1)
    
    total_productos = Producto.objects.filter(activo=True).count()
    stock_bajo = Producto.objects.filter(activo=True, stock__lte=F('stock_minimo')).count()
    total_categorias = Categoria.objects.count()
    valor_inventario = Producto.objects.filter(activo=True).aggregate(
        total=Sum(F('stock') * F('precio_compra'))
    )['total'] or 0
    total_ventas_hoy = Venta.objects.filter(
        fecha_venta__gte=inicio_dia,
        fecha_venta__lt=fin_dia,
        cancelada=False
    ).aggregate(total=Sum('total'))['total'] or 0
    empleados_en_turno = Empleado.objects.filter(activo=True, turnos__abierto=True).distinct().count()

    # Top 5 productos mas vendidos hoy
    top_productos_qs = DetalleVenta.objects.filter(
        venta__fecha_venta__gte=inicio_dia,
        venta__fecha_venta__lt=fin_dia,
        venta__cancelada=False
    ).values(
        'producto__nombre', 'producto__codigo',
        'producto__precio_compra', 'producto__precio_venta',
        'producto__unidad_medida'
    ).annotate(
        total_vendido=Sum('cantidad_base'),
        total_ingreso=Sum('subtotal'),
        total_costo=Sum(F('cantidad_base') * F('producto__precio_compra'))
    ).order_by('-total_vendido')[:5]
    top_productos = []
    for p in top_productos_qs:
        ganancia = (p['total_ingreso'] or 0) - (p['total_costo'] or 0)
        # SUM en SQLite devuelve float (ej. 13.0900000000000): formatear estilo IPB.
        from .models import fmt_cantidad_unidad as _fmtu
        try:
            vendido_fmt = _fmtu(p['total_vendido'] or 0, p.get('producto__unidad_medida') or 'unidades')
        except Exception:
            vendido_fmt = str(p['total_vendido'] or 0)
        top_productos.append({
            **p,
            'ganancia': ganancia,
            'total_vendido_fmt': vendido_fmt,
        })

    context = {
        'total_productos': total_productos,
        'stock_bajo': stock_bajo,
        'total_categorias': total_categorias,
        'valor_inventario': valor_inventario,
        'total_ventas_hoy': total_ventas_hoy,
        'empleados_en_turno': empleados_en_turno,
        'top_productos': top_productos,
    }
    return render(request, 'core/dashboard.html', context)


# ============================================================
# PRODUCTOS
# ============================================================

@requiere_admin
def producto_lista(request):
    productos = Producto.objects.select_related('categoria').order_by('nombre')
    query = request.GET.get('q')
    categoria_id = request.GET.get('categoria')

    if query:
        productos = productos.filter(
            Q(nombre__icontains=query) | Q(codigo__icontains=query)
        )
    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)

    # Paginado: solo los primeros 20 productos por página.
    # Los filtros (q, categoria, riesgo) se conservan en los enlaces.
    paginator = Paginator(productos, 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    params = request.GET.copy()
    params.pop('page', None)
    qs = params.urlencode()

    categorias = Categoria.objects.all()
    context = {
        'productos': page_obj,
        'page_obj': page_obj,
        'qs': qs,
        'categorias': categorias,
        'query': query,
        'categoria_seleccionada': categoria_id,
    }
    return render(request, 'core/producto_lista.html', context)


@requiere_admin
def producto_detalle(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    return render(request, 'core/producto_detalle.html', {'producto': producto})


@requiere_admin
def producto_crear(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save()
            formset = PresentacionFormSet(request.POST, instance=producto)
            if formset.is_valid():
                formset.save()
                _asegurar_presentacion_default(producto)
            else:
                _asegurar_presentacion_default(producto)
                messages.warning(request, 'Producto creado, pero revise las presentaciones.')
            return redirect('core:producto_lista')
        else:
            formset = PresentacionFormSet(request.POST)
    else:
        form = ProductoForm()
        formset = PresentacionFormSet()
    return render(request, 'core/producto_form.html', {
        'form': form, 'formset': formset, 'titulo': 'Crear Producto',
    })


def _presentacion_tiene_venta_hoy(presentacion):
    """True si la presentación se vendió hoy (ventas no canceladas)."""
    if not presentacion or not presentacion.pk:
        return False
    hoy = timezone.localdate()
    return DetalleVenta.objects.filter(
        presentacion=presentacion,
        venta__fecha_venta__date=hoy,
        venta__cancelada=False,
    ).exists()


def _asegurar_presentacion_default(producto):
    """Crea la presentación default x1 si el producto quedó sin ninguna."""
    from .models import PresentacionProducto
    if producto.presentaciones.exists():
        # Si hay pero ninguna marcada default, marca la primera.
        if not producto.presentaciones.filter(es_default=True).exists():
            primera = producto.presentaciones.order_by('factor').first()
            primera.es_default = True
            primera.save(update_fields=['es_default'])
        return
    nombres = {'kg': 'Kilogramo', 'lb': 'Libra', 'metros': 'Metro',
               'unidades': 'Unidad', 'gramos': 'Gramo'}
    PresentacionProducto.objects.create(
        producto=producto,
        nombre=nombres.get(producto.unidad_medida, 'Unidad'),
        factor=1,
        precio=producto.precio_venta,
        es_default=True,
        activo=True,
    )


@requiere_admin
def producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        # El stock NO se toca aquí: solo se modifica desde Ajustes (o Entradas/Ventas/POS)
        form.fields.pop('stock', None)
        formset = PresentacionFormSet(request.POST, instance=producto)
        if form.is_valid() and formset.is_valid():
            # Bloquear borrado (checkbox DELETE) si la presentación se vendió hoy
            bloqueadas = [
                f.instance.nombre for f in formset.deleted_forms
                if f.instance.pk and _presentacion_tiene_venta_hoy(f.instance)
            ]
            if bloqueadas:
                messages.error(
                    request,
                    'No se puede borrar ' + ', '.join('"%s"' % n for n in bloqueadas) +
                    ': tiene venta(s) en el día de hoy.'
                )
            else:
                form.save()
                formset.save()
                _asegurar_presentacion_default(producto)
                return redirect('core:producto_detalle', pk=producto.pk)
    else:
        form = ProductoForm(instance=producto)
        form.fields.pop('stock', None)
        formset = PresentacionFormSet(instance=producto)
    # Marcar qué presentaciones tienen venta hoy para bloquear su borrado en el template
    for f in formset.forms:
        try:
            f.tiene_venta_hoy = bool(f.instance.pk and _presentacion_tiene_venta_hoy(f.instance))
        except Exception:
            f.tiene_venta_hoy = False
    return render(request, 'core/producto_form.html', {
        'form': form,
        'formset': formset,
        'titulo': 'Editar Producto',
        'producto': producto,
    })


@requiere_admin
@require_POST
def presentacion_eliminar(request, pk):
    """Borrado directo de una presentación (cruz ✕ de la tarjeta).

    - 409 si tiene venta(s) en el día de hoy.
    - Si tiene historial (ventas/deudas de otros días) se desactiva en vez de
      borrar (las FK son PROTECT) para no romper el historial.
    - Si no, se elimina de forma permanente.
    """
    from .models import PresentacionProducto
    pres = get_object_or_404(PresentacionProducto, pk=pk)
    if _presentacion_tiene_venta_hoy(pres):
        return JsonResponse(
            {'ok': False, 'error': f'No se puede borrar "{pres.nombre}": tiene venta(s) en el día de hoy.'},
            status=409,
        )
    tiene_historial = (
        DetalleVenta.objects.filter(presentacion=pres).exists()
        or Deuda.objects.filter(presentacion=pres).exists()
    )
    try:
        if tiene_historial:
            pres.activo = False
            if pres.es_default:
                pres.es_default = False
            pres.save(update_fields=['activo', 'es_default'])
            _asegurar_presentacion_default(pres.producto)
            return JsonResponse({'ok': True, 'desactivada': True})
        nombre = pres.nombre
        producto = pres.producto
        pres.delete()
        _asegurar_presentacion_default(producto)
        return JsonResponse({'ok': True, 'desactivada': False})
    except Exception as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=500)


@requiere_admin
@require_POST
def producto_imagen_eliminar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if producto.imagen:
        try:
            producto.imagen.delete(save=False)
        except Exception:
            pass
        producto.imagen = None
        producto.save(update_fields=['imagen'])
        messages.success(request, f'Imagen de "{producto.nombre}" eliminada.')
    # Respuesta JSON para borrado directo por AJAX/fetch (botón Eliminar)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'ok': True})
    return redirect('core:producto_editar', pk=pk)


@requiere_admin
def producto_eliminar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        from .models import DetalleVenta, EntradaProducto, RetiroDonacion, MovimientoInventario, InventarioDiario
        # Check ALL related models (PROTECT and CASCADE) for any existing records
        related_models = [
            ('Detalles de venta', DetalleVenta.objects.filter(producto=producto)),
            ('Entradas de inventario', EntradaProducto.objects.filter(producto=producto)),
            ('Retiros por donacion', RetiroDonacion.objects.filter(producto=producto)),
            ('Movimientos de inventario', MovimientoInventario.objects.filter(producto=producto)),
            ('Inventarios diarios', InventarioDiario.objects.filter(producto=producto)),
        ]
        
        referenced_by = [(name, qs.count()) for name, qs in related_models if qs.exists()]
        
        if referenced_by:
            # Soft delete: deactivate - product has historical records
            producto.activo = False
            producto.save()
            detalles = ', '.join([f"{name} ({count} registros)" for name, count in referenced_by])
            messages.warning(request, f'Producto "{producto.nombre}" desactivado. No se puede eliminar porque tiene registros historicos: {detalles}.')
        else:
            # Safe to hard delete
            nombre = producto.nombre
            producto.delete()
            messages.success(request, f'Producto "{nombre}" eliminado permanentemente.')
        return redirect('core:producto_lista')
    return render(request, 'core/producto_confirmar_eliminar.html', {'producto': producto})


@requiere_admin
@require_POST
def producto_eliminar_definitivo(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    try:
        from .models import DetalleVenta, EntradaProducto, RetiroDonacion, MovimientoInventario, InventarioDiario
        # Check ALL related models (PROTECT and CASCADE) for any existing records
        related_models = [
            ('Detalles de venta', DetalleVenta.objects.filter(producto=producto)),
            ('Entradas de inventario', EntradaProducto.objects.filter(producto=producto)),
            ('Retiros por donacion', RetiroDonacion.objects.filter(producto=producto)),
            ('Movimientos de inventario', MovimientoInventario.objects.filter(producto=producto)),
            ('Inventarios diarios', InventarioDiario.objects.filter(producto=producto)),
        ]
        
        referenced_by = [(name, qs.count()) for name, qs in related_models if qs.exists()]
        
        if referenced_by:
            # Soft delete: deactivate - product has historical records
            producto.activo = False
            producto.save()
            detalles = ', '.join([f"{name} ({count} registros)" for name, count in referenced_by])
            return JsonResponse({
                'success': True,
                'message': f'Producto "{producto.nombre}" desactivado. Tiene registros historicos: {detalles}.',
                'deactivated': True
            })
        else:
            # Safe to hard delete
            nombre = producto.nombre
            producto.delete()
            return JsonResponse({'success': True, 'message': f'Producto "{nombre}" eliminado permanentemente.', 'deactivated': False})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


# ============================================================
# CATEGORIAS
# ============================================================

@requiere_admin
def categoria_lista(request):
    categorias = Categoria.objects.annotate(num_productos=Count('productos'))
    return render(request, 'core/categoria_lista.html', {'categorias': categorias})


@requiere_admin
def categoria_crear(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('core:categoria_lista')
    else:
        form = CategoriaForm()
    return render(request, 'core/categoria_form.html', {'form': form, 'titulo': 'Crear Categoria'})


@requiere_admin
def categoria_editar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            return redirect('core:categoria_lista')
    else:
        form = CategoriaForm(instance=categoria)
    return render(request, 'core/categoria_form.html', {'form': form, 'titulo': 'Editar Categoria'})


@requiere_admin
def categoria_eliminar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        categoria.delete()
        return redirect('core:categoria_lista')
    return render(request, 'core/categoria_confirmar_eliminar.html', {'categoria': categoria})


# ============================================================
# EMPLEADOS
# ============================================================

@requiere_admin
def empleado_lista(request):
    empleados = Empleado.objects.select_related('user').all()
    context = {
        'empleados': empleados,
        'ahora': timezone.make_aware(ahora_servidor()),
    }
    return render(request, 'core/empleado_lista.html', context)


@requiere_admin
def empleado_crear(request):
    if request.method == 'POST':
        form = EmpleadoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Empleado creado correctamente.')
            return redirect('core:empleado_lista')
    else:
        form = EmpleadoForm()
    return render(request, 'core/empleado_form.html', {'form': form, 'titulo': 'Crear Empleado'})


@requiere_admin
def empleado_editar(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    if request.method == 'POST':
        form = EmpleadoForm(request.POST, instance=empleado, user_instance=empleado.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Empleado actualizado correctamente.')
            return redirect('core:empleado_lista')
    else:
        form = EmpleadoForm(instance=empleado, user_instance=empleado.user)
    return render(request, 'core/empleado_form.html', {
        'form': form,
        'titulo': 'Editar Empleado',
        'empleado': empleado,
    })


@requiere_admin
@require_POST
def empleado_toggle_activo(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    empleado.activo = not empleado.activo
    empleado.save()
    empleado.user.is_active = empleado.activo
    empleado.user.save()
    estado = 'activado' if empleado.activo else 'desactivado'
    messages.success(request, f'Empleado {estado} correctamente.')
    return redirect('core:empleado_lista')


@requiere_admin
def empleado_eliminar(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    if request.method == 'POST':
        nombre = str(empleado)
        try:
            empleado.user.delete()
            messages.success(request, f'Empleado {nombre} eliminado.')
        except ProtectedError:
            # Tiene ventas/gastos u otros registros: no se puede borrar,
            # se desactiva para que no inicie sesión ni venda.
            empleado.activo = False
            empleado.save(update_fields=['activo'])
            user = empleado.user
            user.is_active = False
            user.save(update_fields=['is_active'])
            messages.warning(
                request,
                f'{nombre} tiene movimientos registrados y no se puede eliminar: '
                'se desactivó y ya no puede iniciar sesión.')
        return redirect('core:empleado_lista')
    return render(request, 'core/empleado_confirmar_eliminar.html', {'empleado': empleado})


# ============================================================
# TURNOS
# ============================================================

@requiere_admin
@require_POST
def turno_abrir(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk, activo=True)
    if empleado.en_turno:
        messages.warning(request, f'{empleado} ya tiene un turno abierto.')
    else:
        Turno.objects.create(empleado=empleado)
        messages.success(request, f'Turno abierto para {empleado}.')
    return redirect('core:empleado_lista')


@requiere_admin
def empleado_turnos(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    turnos = empleado.turnos.all()[:30]
    return render(request, 'core/empleado_turnos.html', {
        'empleado': empleado,
        'turnos': turnos,
    })


# ============================================================
# VENTAS
# ============================================================

@requiere_admin
def venta_lista(request):
    from datetime import timedelta
    from django.utils import timezone
    fecha_str = request.GET.get('fecha', '')
    empleado_filtro = request.GET.get('empleado', '')
    periodo = request.GET.get('periodo', 'dia')

    hoy = ahora_servidor().date()
    
    if fecha_str:
        try:
            fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
        except ValueError:
            fecha = hoy
    else:
        fecha = hoy

    ventas = Venta.objects.filter(cancelada=False).select_related('cajero')

    if periodo == 'dia':
        titulo = f'Ventas del dia {fecha.strftime("%d/%m/%Y")}'
        fecha_dt = timezone.make_aware(timezone.datetime.combine(fecha, timezone.datetime.min.time()))
        fd = fecha_dt
        fh = fecha_dt + timedelta(days=1)
        ventas = ventas.filter(fecha_venta__gte=fd, fecha_venta__lt=fh)
    elif periodo == 'mes':
        titulo = f'Ventas de {fecha.strftime("%B %Y")}'
        ventas = ventas.filter(
            fecha_venta__year=fecha.year,
            fecha_venta__month=fecha.month
        )
    elif periodo == 'ano':
        titulo = f'Ventas del ano {fecha.year}'
        ventas = ventas.filter(fecha_venta__year=fecha.year)
    else:
        titulo = f'Ventas del dia {fecha.strftime("%d/%m/%Y")}'
        ventas = ventas.filter(fecha_venta__date=fecha)

    if empleado_filtro:
        ventas = ventas.filter(cajero__username=empleado_filtro)

    resumen = ventas.aggregate(
        total=Sum('total') or 0,
        cantidad=Count('id')
    )
    
    # Resumen de dinero por tipo de pago
    # OJO: monto_recibido es el efectivo ENTREGADO (incluye el cambio devuelto),
    # por eso el efectivo neto = recibido - cambio. Asi cuadra:
    #   efectivo_neto + transferencia = total de ventas.
    resumen_dinero = ventas.aggregate(
        efectivo=Sum('monto_recibido'),
        transferencia=Sum('monto_transferencia'),
        cambio=Sum('cambio'),
    )
    
    # Gastos del periodo
    gastos_qs = Gasto.objects.filter(fecha_gasto__date=fecha) if periodo == 'dia' else Gasto.objects.all()
    if periodo == 'dia':
        gastos_qs = gastos_qs.filter(fecha_gasto__date=fecha)
    elif periodo == 'mes':
        gastos_qs = gastos_qs.filter(fecha_gasto__year=fecha.year, fecha_gasto__month=fecha.month)
    elif periodo == 'ano':
        gastos_qs = gastos_qs.filter(fecha_gasto__year=fecha.year)
    
    if empleado_filtro:
        gastos_qs = gastos_qs.filter(cajero__username=empleado_filtro)
    
    resumen_gastos = gastos_qs.aggregate(
        total=Sum(F('cantidad_efectivo') + F('cantidad_transferencia')) or 0,
        cantidad=Count('id')
    )

    empleados = Empleado.objects.filter(activo=True).select_related('user')

    context = {
        'ventas': ventas,
        'fecha': fecha.strftime('%Y-%m-%d'),
        'periodo': periodo,
        'titulo': titulo,
        'empleado_filtro': empleado_filtro,
        'empleados': empleados,
        'resumen_total': resumen['total'] or 0,
        'resumen_cantidad': resumen['cantidad'] or 0,
        'resumen_efectivo': (resumen_dinero['efectivo'] or 0) - (resumen_dinero['cambio'] or 0),
        'resumen_efectivo_recibido': resumen_dinero['efectivo'] or 0,
        'resumen_cambio': resumen_dinero['cambio'] or 0,
        'resumen_transferencia': resumen_dinero['transferencia'] or 0,
        'resumen_gastos': resumen_gastos['total'] or 0,
        'resumen_gastos_cantidad': resumen_gastos['cantidad'] or 0,
        'resumen_neto': (resumen['total'] or 0) - (resumen_gastos['total'] or 0),
        'hoy': hoy.strftime('%Y-%m-%d'),
    }
    return render(request, 'core/venta_lista.html', context)


@requiere_admin
def venta_crear(request):
    productos = Producto.objects.filter(activo=True).select_related('categoria').order_by('nombre')
    empleados = Empleado.objects.filter(activo=True).select_related('user')
    hoy = ahora_servidor().date()

    if request.method == 'POST':
        empleado_id = request.POST.get('cajero')
        fecha_str = request.POST.get('fecha', '')
        metodo_pago = request.POST.get('metodo_pago', 'efectivo')
        monto_efectivo = Decimal(request.POST.get('monto_efectivo') or '0')
        monto_transferencia = Decimal(request.POST.get('monto_transferencia') or '0')
        productos_data = request.POST.get('productos_data', '')

        try:
            cajero = User.objects.get(empleado__id=empleado_id) if empleado_id else request.user
            
            if fecha_str:
                fecha_hora = timezone.datetime.strptime(fecha_str + ' ' + ahora_servidor().strftime('%H:%M'), '%Y-%m-%d %H:%M')
                fecha_hora = timezone.make_aware(fecha_hora)
            else:
                fecha_hora = timezone.make_aware(ahora_servidor())

            numero_venta = Venta.generar_numero()
            total = Decimal(0)
            
            if metodo_pago == 'mixto':
                total = monto_efectivo + monto_transferencia
            elif metodo_pago == 'efectivo':
                total = monto_efectivo
            else:
                total = monto_transferencia

            venta = Venta.objects.create(
                numero=numero_venta,
                cajero=cajero,
                metodo_pago=metodo_pago,
                monto_recibido=monto_efectivo,
                monto_transferencia=monto_transferencia,
                total=total,
                cambio=0,
                fecha_venta=fecha_hora,
                cancelada=False,
            )

            if productos_data:
                import json
                items = json.loads(productos_data)
                for item in items:
                    producto = Producto.objects.get(pk=item['producto_id'])
                    cantidad = int(item['cantidad'])
                    precio = producto.precio_venta
                    DetalleVenta.objects.create(
                        venta=venta,
                        producto=producto,
                        cantidad=cantidad,
                        precio_unitario=precio,
                        subtotal=cantidad * precio,
                    )
                    producto.stock -= cantidad
                    producto.save()

            messages.success(request, f'Venta {numero_venta} registrada correctamente.')
            return redirect('core:venta_lista')
        except Exception as e:
            messages.error(request, f'Error al registrar venta: {str(e)}')

    context = {
        'productos': productos,
        'empleados': empleados,
        'fecha_default': hoy.strftime('%Y-%m-%d'),
    }
    return render(request, 'core/venta_form.html', context)


@requiere_admin
def venta_detalle(request, pk):
    venta = get_object_or_404(Venta.objects.select_related('cajero', 'turno__empleado'), pk=pk)
    detalles = venta.detalles.select_related('producto', 'presentacion').all()
    return render(request, 'core/venta_detalle.html', {
        'venta': venta,
        'detalles': detalles,
    })


@requiere_admin
def venta_editar(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    detalles = venta.detalles.select_related('producto', 'presentacion').all()
    productos = Producto.objects.filter(activo=True).prefetch_related('presentaciones')

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'agregar_producto':
            producto_id = request.POST.get('producto_id')
            presentacion_id = request.POST.get('presentacion_id') or None
            try:
                cantidad = Decimal(str(request.POST.get('cantidad', '1')))
            except Exception:
                messages.error(request, 'Cantidad inválida.')
                return redirect('core:venta_editar', pk=venta.pk)
            producto = get_object_or_404(Producto, pk=producto_id)
            if cantidad <= 0:
                messages.error(request, 'Cantidad inválida.')
                return redirect('core:venta_editar', pk=venta.pk)
            if not producto.permite_decimal and cantidad != cantidad.to_integral_value():
                messages.error(request, f'{producto.nombre} solo admite unidades enteras.')
                return redirect('core:venta_editar', pk=venta.pk)
            presentacion, factor, precio = _resolver_presentacion(producto, presentacion_id)
            cantidad_base = (cantidad * factor).quantize(Decimal('0.001'))
            if cantidad_base > producto.stock:
                messages.error(request, f'Stock insuficiente. Disponible: {"%g" % float(producto.stock)} {producto.unidad_medida}.')
                return redirect('core:venta_editar', pk=venta.pk)

            detalle_existente = detalles.filter(producto=producto, presentacion=presentacion).first()
            if detalle_existente:
                detalle_existente.cantidad += cantidad
                detalle_existente.cantidad_base += cantidad_base
                detalle_existente.subtotal = detalle_existente.cantidad * detalle_existente.precio_unitario
                detalle_existente.save()
            else:
                DetalleVenta.objects.create(
                    venta=venta,
                    producto=producto,
                    presentacion=presentacion,
                    cantidad=cantidad,
                    cantidad_base=cantidad_base,
                    precio_unitario=precio,
                    subtotal=precio * cantidad
                )

            _registrar_movimiento(producto, 'venta', cantidad_base, request.user, venta.id, f'Venta #{venta.numero_venta} - Producto agregado en edición')
            _sincronizar_inventario_dia(venta.fecha_venta.date())

            _recalcular_venta(venta)
            messages.success(request, f'Producto {producto.nombre} agregado.')
            return redirect('core:venta_editar', pk=venta.pk)

        elif action == 'eliminar_detalle':
            detalle_id = request.POST.get('detalle_id')
            detalle = get_object_or_404(DetalleVenta, pk=detalle_id, venta=venta)
            nombre = detalle.producto.nombre
            cantidad_devuelta = detalle.cantidad_base or detalle.cantidad
            producto = detalle.producto
            detalle.delete()
            _registrar_movimiento(producto, 'devolucion', cantidad_devuelta, request.user, venta.id, f'Venta #{venta.numero_venta} - Producto eliminado en edición')
            _sincronizar_inventario_dia(venta.fecha_venta.date())
            _recalcular_venta(venta)
            messages.success(request, f'Producto {nombre} eliminado.')
            return redirect('core:venta_editar', pk=venta.pk)

        elif action == 'actualizar_cantidad':
            detalle_id = request.POST.get('detalle_id')
            try:
                cantidad_nueva = Decimal(str(request.POST.get('cantidad', '1')))
            except Exception:
                return redirect('core:venta_editar', pk=venta.pk)
            detalle = get_object_or_404(DetalleVenta, pk=detalle_id, venta=venta)
            factor = detalle.presentacion.factor if detalle.presentacion_id and detalle.presentacion else Decimal('1')
            cantidad_anterior = detalle.cantidad
            base_anterior = detalle.cantidad_base or (cantidad_anterior * factor)
            cantidad_base_nueva = (cantidad_nueva * factor).quantize(Decimal('0.001'))
            diferencia_base = cantidad_base_nueva - base_anterior

            if cantidad_nueva <= 0:
                producto = detalle.producto
                detalle.delete()
                _registrar_movimiento(producto, 'devolucion', base_anterior, request.user, venta.id, f'Venta #{venta.numero_venta} - Producto eliminado en edición')
                _sincronizar_inventario_dia(venta.fecha_venta.date())
            else:
                if diferencia_base > 0 and diferencia_base > detalle.producto.stock:
                    messages.error(request, 'Stock insuficiente para aumentar la cantidad.')
                    return redirect('core:venta_editar', pk=venta.pk)
                detalle.cantidad = cantidad_nueva
                detalle.cantidad_base = cantidad_base_nueva
                detalle.subtotal = cantidad_nueva * detalle.precio_unitario
                detalle.save()
                if diferencia_base > 0:
                    _registrar_movimiento(detalle.producto, 'venta', diferencia_base, request.user, venta.id, f'Venta #{venta.numero_venta} - Cantidad aumentada en edición')
                elif diferencia_base < 0:
                    _registrar_movimiento(detalle.producto, 'devolucion', abs(diferencia_base), request.user, venta.id, f'Venta #{venta.numero_venta} - Cantidad reducida en edición')
                _sincronizar_inventario_dia(venta.fecha_venta.date())
            _recalcular_venta(venta)
            return redirect('core:venta_editar', pk=venta.pk)

        elif action == 'cancelar_venta':
            venta.cancelada = True
            venta.save()
            for detalle in venta.detalles.all():
                _registrar_movimiento(detalle.producto, 'devolucion', detalle.cantidad_base or detalle.cantidad, request.user, venta.id, f'Venta #{venta.numero_venta} cancelada')
            _sincronizar_inventario_dia(venta.fecha_venta.date())
            messages.success(request, f'Venta {venta.numero_venta} cancelada. Stock restaurado.')
            return redirect('core:venta_lista')

        elif action == 'actualizar_pago':
            metodo_pago = request.POST.get('metodo_pago', 'efectivo')
            monto_efectivo = Decimal(request.POST.get('monto_efectivo') or '0')
            monto_transferencia = Decimal(request.POST.get('monto_transferencia') or '0')
            
            venta.metodo_pago = metodo_pago
            venta.monto_recibido = monto_efectivo
            venta.monto_transferencia = monto_transferencia
            
            total_pagado = monto_efectivo + monto_transferencia
            if total_pagado >= venta.total:
                venta.cambio = total_pagado - venta.total
            else:
                venta.cambio = 0
            
            venta.save()
            messages.success(request, 'Metodo de pago actualizado.')
            return redirect('core:venta_editar', pk=venta.pk)

        elif action == 'guardar':
            messages.success(request, 'Venta actualizada correctamente.')
            return redirect('core:venta_detalle', pk=venta.pk)

    return render(request, 'core/venta_editar.html', {
        'venta': venta,
        'detalles': detalles,
        'productos': productos,
    })


def _recalcular_venta(venta):
    detalles = venta.detalles.all()
    subtotal = sum(d.subtotal for d in detalles)
    venta.subtotal = subtotal
    venta.total = subtotal
    venta.save()


# ============================================================
# PUNTO DE VENTA
# ============================================================

@login_required
def pos(request):
    # Verificar si es cajero y si tiene turno abierto
    try:
        perfil = request.user.perfil
        if perfil.es_cajero:
            try:
                empleado = request.user.empleado
                if not empleado.en_turno:
                    return render(request, 'core/pos_sin_turno.html', {'empleado': empleado})
            except Empleado.DoesNotExist:
                return render(request, 'core/pos_sin_turno.html', {'empleado': None})
    except PerfilUsuario.DoesNotExist:
        pass

    productos = Producto.objects.filter(activo=True, stock__gt=0).select_related('categoria').prefetch_related('presentaciones').order_by('nombre')
    categorias = Categoria.objects.filter(productos__activo=True, productos__stock__gt=0).distinct()
    
    es_admin = request.user.perfil.es_admin if hasattr(request.user, 'perfil') else False

    context = {
        'productos': productos,
        'categorias': categorias,
        'es_admin': es_admin,
    }
    return render(request, 'core/pos.html', context)


def _serializar_producto_pos(p):
    """Producto + presentaciones para el POS (precio manual por presentación)."""
    pres = [{
        'id': pr.id,
        'nombre': pr.nombre,
        'factor': str(pr.factor),
        'precio': str(pr.precio),
        'es_default': pr.es_default,
    } for pr in p.presentaciones.filter(activo=True).order_by('-es_default', 'factor')]
    if not pres:
        pres = [{'id': None, 'nombre': 'Unidad', 'factor': '1',
                 'precio': str(p.precio_venta), 'es_default': True}]
    return {
        'id': p.id,
        'codigo': p.codigo,
        'nombre': p.nombre,
        'precio': str(p.precio_para()),
        'stock': str(p.stock),
        'stock_display': ('%g' % float(p.stock)),
        'unidad': p.unidad_medida,
        'permite_decimal': p.permite_decimal,
        'imagen': p.imagen_url,
        'categoria': p.categoria.nombre if p.categoria else '',
        'categoria_id': p.categoria_id,
        'presentaciones': pres,
    }


@login_required
@require_POST
def pos_buscar_productos(request):
    query = request.POST.get('q', '').strip()
    categoria_id = request.POST.get('categoria', '')

    productos = Producto.objects.filter(activo=True, stock__gt=0).select_related(
        'categoria').prefetch_related('presentaciones')
    if query:
        productos = productos.filter(
            Q(nombre__icontains=query) | Q(codigo__icontains=query)
        )
    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)

    data = [_serializar_producto_pos(p) for p in productos[:50]]

    return JsonResponse({'productos': data})


def _resolver_presentacion(producto, presentacion_id):
    """Devuelve (presentacion|None, factor, precio manual)."""
    from .models import PresentacionProducto
    if presentacion_id:
        try:
            pr = PresentacionProducto.objects.get(
                pk=presentacion_id, producto=producto, activo=True)
            return pr, pr.factor, pr.precio
        except PresentacionProducto.DoesNotExist:
            pass
    d = producto.presentacion_default()
    if d:
        return d, d.factor, d.precio
    return None, Decimal('1'), producto.precio_venta


@login_required
@require_POST
def pos_procesar_venta(request):
    try:
        data = json.loads(request.body)
        items = data.get('items', [])
        metodo_pago = data.get('metodo_pago', 'efectivo')
        monto_efectivo = Decimal(str(data.get('monto_recibido', 0)))
        monto_transferencia = Decimal(str(data.get('monto_transferencia', 0)))

        if not items:
            return JsonResponse({'error': 'No hay productos en la venta.'}, status=400)

        subtotal = Decimal('0')
        detalles_data = []

        for item in items:
            producto = get_object_or_404(Producto, pk=item['id'])
            try:
                cantidad = Decimal(str(item['cantidad']))
            except Exception:
                return JsonResponse({'error': f'Cantidad invalida para {producto.nombre}.'}, status=400)
            if cantidad <= 0:
                return JsonResponse({'error': f'Cantidad invalida para {producto.nombre}.'}, status=400)
            # Solo 3 decimales
            cantidad = cantidad.quantize(Decimal('0.001'))
            # Enteros obligatorios salvo permite_decimal (cerdo, medio cartón...)
            if not producto.permite_decimal and cantidad != cantidad.to_integral_value():
                return JsonResponse({'error': f'{producto.nombre} solo admite unidades enteras.'}, status=400)
            presentacion, factor, precio = _resolver_presentacion(
                producto, item.get('presentacion_id'))
            cantidad_base = (cantidad * factor).quantize(Decimal('0.001'))
            if cantidad_base <= 0:
                return JsonResponse({'error': f'Cantidad invalida para {producto.nombre}.'}, status=400)
            if cantidad_base > producto.stock:
                return JsonResponse({'error': f'Stock insuficiente para {producto.nombre}. Disponible: {"%g" % float(producto.stock)} {producto.unidad_medida}'}, status=400)
            item_subtotal = precio * cantidad
            subtotal += item_subtotal
            detalles_data.append({
                'producto': producto,
                'presentacion': presentacion,
                'cantidad': cantidad,
                'cantidad_base': cantidad_base,
                'precio_unitario': precio,
                'subtotal': item_subtotal,
            })

        total = subtotal
        total_pagado = monto_efectivo + monto_transferencia

        if total_pagado < total:
            return JsonResponse({'error': 'El monto pagado es insuficiente.'}, status=400)

        cambio = total_pagado - total

        # Obtener turno activo del empleado
        turno = None
        try:
            empleado = request.user.empleado
            turno = empleado.turno_abierto
        except Empleado.DoesNotExist:
            pass

        numero_venta = Venta.generar_numero()
        venta = Venta.objects.create(
            numero_venta=numero_venta,
            cajero=request.user,
            turno=turno,
            subtotal=subtotal,
            impuesto=Decimal('0'),
            total=total,
            metodo_pago=metodo_pago,
            monto_recibido=monto_efectivo,
            monto_transferencia=monto_transferencia,
            cambio=cambio,
        )

        for d in detalles_data:
            DetalleVenta.objects.create(
                venta=venta,
                producto=d['producto'],
                presentacion=d['presentacion'],
                cantidad=d['cantidad'],
                cantidad_base=d['cantidad_base'],
                precio_unitario=d['precio_unitario'],
                subtotal=d['subtotal'],
            )
            _registrar_movimiento(d['producto'], 'venta', d['cantidad_base'], request.user, venta.id, f'Venta #{venta.numero_venta}')

        _sincronizar_inventario_dia(ahora_servidor().date())

        return JsonResponse({
            'success': True,
            'venta_id': venta.id,
            'numero_venta': venta.numero_venta,
            'total': str(venta.total),
            'cambio': str(venta.cambio),
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
def pos_ping(request):
    """Ping liviano para el monitor offline del POS. No requiere turno."""
    return JsonResponse({'ok': True})


@login_required
def pos_catalogo(request):
    """Catálogo completo para cache offline del POS (productos + categorías)."""
    productos = Producto.objects.filter(activo=True).select_related(
        'categoria').prefetch_related('presentaciones').order_by('nombre')[:2000]
    data = [_serializar_producto_pos(p) for p in productos]
    categorias = list(Categoria.objects.filter(
        productos__activo=True).distinct().values('id', 'nombre'))
    return JsonResponse({'productos': data, 'categorias': categorias})


@login_required
def pos_ticket(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    if venta.cajero != request.user and not request.user.perfil.es_admin:
        return redirect('core:pos')
    detalles = venta.detalles.select_related('producto', 'presentacion').all()
    return render(request, 'core/pos_ticket.html', {'venta': venta, 'detalles': detalles})


@login_required
def pos_mis_ventas(request):
    hoy = ahora_servidor().date()
    ventas = Venta.objects.filter(
        cajero=request.user,
        fecha_venta__date=hoy,
        cancelada=False
    ).order_by('-fecha_venta')

    resumen = ventas.aggregate(total=Sum('total'), cantidad=Count('id'))

    data = []
    for v in ventas:
        detalles = v.detalles.select_related('producto').all()
        data.append({
            'id': v.id,
            'numero': v.numero_venta,
            'total': str(v.total),
            'metodo': v.get_metodo_pago_display(),
            'monto_recibido': str(v.monto_recibido),
            'monto_transferencia': str(v.monto_transferencia),
            'cambio': str(v.cambio),
            'hora': v.fecha_venta.strftime('%H:%M'),
            'items': [{
                'nombre': d.producto.nombre,
                'presentacion': d.presentacion.nombre if d.presentacion_id and d.presentacion else '',
                'cantidad': str(d.cantidad),
                'cantidad_base': str(d.cantidad_base or d.cantidad),
                'precio': str(d.precio_unitario),
                'subtotal': str(d.subtotal),
            } for d in detalles],
        })

    return JsonResponse({
        'ventas': data,
        'resumen': {
            'total': str(resumen['total'] or 0),
            'cantidad': resumen['cantidad'] or 0,
        }
    })


# ============================================================
# IPB - INVENTARIO PARCIAL DEL DIA
# ============================================================

def _fmt_cantidad_ipb(valor, unidad_medida):
    """Formato de cantidades para el IPB (usa el helper compartido de models)."""
    return fmt_cantidad_unidad(valor, unidad_medida)


def _obtener_datos_ipb(fecha):
    """Prepara los datos del IPB para una fecha dada. Retorna un diccionio con el contexto."""
    from datetime import timedelta
    from django.db.models import Sum
    
    hoy = ahora_servidor().date()
    
    _sincronizar_inventario_dia(fecha)
    
    inventarios = InventarioDiario.objects.filter(
        fecha=fecha,
        producto__activo=True
    ).select_related('producto__categoria').order_by('producto__nombre')
    
    entradas_dia = EntradaProducto.objects.filter(
        fecha_entrada__date=fecha
    ).values('producto_id').annotate(
        total_costo=Sum('costo_total'),
        total_cantidad=Sum('cantidad')
    )
    entrada_costo_map = {e['producto_id']: {'costo': Decimal(str(e['total_costo'] or 0)), 'cantidad': Decimal(str(e['total_cantidad'] or 0))} for e in entradas_dia}

    # Ingreso REAL por producto: suma de los subtotales cobrados (cada
    # presentación tiene su precio: cartón ≠ unidad). Sin esto, 130 huevos
    # a $170 + 2 cartones a $4500 se calcularían como 190 x $170.
    ventas_det = DetalleVenta.objects.filter(
        venta__fecha_venta__date=fecha, venta__cancelada=False
    ).values('producto_id').annotate(ingreso_real=Sum('subtotal'))
    ingreso_map = {v['producto_id']: Decimal(str(v['ingreso_real'] or 0)) for v in ventas_det}
    # Desglose por presentación para mostrar el mix (ej. "2 x Cartón 30").
    # Solo presentaciones distintas a la unidad base (factor != 1): las ventas
    # en unidades no ensucian el IPB.
    mix_qs = DetalleVenta.objects.filter(
        venta__fecha_venta__date=fecha, venta__cancelada=False
    ).values('producto_id', 'presentacion__nombre', 'presentacion__factor').annotate(
        cant=Sum('cantidad'), sub=Sum('subtotal'))
    mix_map = {}
    for m in mix_qs:
        if not m['presentacion__nombre']:
            continue
        try:
            if Decimal(str(m['presentacion__factor'] or 1)) == 1:
                continue
        except Exception:
            pass
        try:
            c = Decimal(str(m['cant'] or 0))
            cs = format(c.quantize(Decimal('0.001')).normalize(), 'f')
        except Exception:
            cs = str(m['cant'] or 0)
        nombre = m['presentacion__nombre']
        mix_map.setdefault(m['producto_id'], []).append(f"{cs} x {nombre}")

    # Salidas sin venta del día: donaciones y deudas de producto (para marcar el IPB).
    # Deudas: sumar cantidad_base (presentación convertida); fallback a cantidad
    # para registros viejos con cantidad_base en 0.
    from django.db.models import Sum as _Sum
    donaciones_dia = RetiroDonacion.objects.filter(
        fecha_retiro__date=fecha
    ).values('producto_id').annotate(total=_Sum('cantidad'))
    donado_map = {d['producto_id']: Decimal(str(d['total'] or 0)) for d in donaciones_dia}
    try:
        deudas_dia = Deuda.objects.filter(
            fecha_registro__date=fecha, tipo='producto'
        ).values('producto_id').annotate(total=_Sum('cantidad_base'))
        deuda_map = {d['producto_id']: Decimal(str(d['total'] or 0)) for d in deudas_dia}
        # Fallback: registros anteriores a la migración de presentaciones
        # (cantidad_base = 0) se miden con cantidad.
        if any(v == 0 for v in deuda_map.values()):
            deudas_old = Deuda.objects.filter(
                fecha_registro__date=fecha, tipo='producto', cantidad_base=0
            ).values('producto_id').annotate(total=_Sum('cantidad'))
            for d in deudas_old:
                if deuda_map.get(d['producto_id'], 0) == 0:
                    deuda_map[d['producto_id']] = Decimal(str(d['total'] or 0))
    except Exception:
        deudas_dia = Deuda.objects.filter(
            fecha_registro__date=fecha, tipo='producto'
        ).values('producto_id').annotate(total=_Sum('cantidad'))
        deuda_map = {d['producto_id']: Decimal(str(d['total'] or 0)) for d in deudas_dia}
    
    total_inicial = 0
    total_entradas = 0
    total_ventas = 0
    total_final = 0
    productos_movimiento = 0
    productos_sin_stock = 0
    total_donado = Decimal('0')
    total_en_deuda = Decimal('0')
    productos_donados = 0
    productos_en_deuda = 0
    
    reporte = []
    for inv in inventarios:
        total_inicial += inv.stock_inicial
        total_entradas += inv.entradas
        total_ventas += inv.ventas
        total_final += inv.stock_final
        
        if inv.ventas > 0 or inv.entradas > 0:
            productos_movimiento += 1
        if inv.stock_final == 0 and inv.ventas > 0:
            productos_sin_stock += 1
        
        precio_venta = Decimal(str(inv.producto.precio_venta))
        
        entrada_info = entrada_costo_map.get(inv.producto.id)
        if entrada_info and entrada_info['cantidad'] > 0:
            costo_promedio_entrada = entrada_info['costo'] / entrada_info['cantidad']
        else:
            costo_promedio_entrada = inv.producto.precio_compra
        
        costo_venta = inv.ventas * costo_promedio_entrada
        # Ingreso real cobrado (respeta precios por presentación); fallback al
        # precio base solo si no hay detalle (no debería pasar con ventas > 0).
        ingreso = ingreso_map.get(inv.producto.id, inv.ventas * precio_venta)
        ganancia = ingreso - costo_venta

        donado = donado_map.get(inv.producto.id, Decimal('0'))
        en_deuda = deuda_map.get(inv.producto.id, Decimal('0'))
        if donado > 0:
            total_donado += donado
            productos_donados += 1
        if en_deuda > 0:
            total_en_deuda += en_deuda
            productos_en_deuda += 1

        reporte.append({
            'inventario': inv,
            'producto': inv.producto,
            'categoria': inv.producto.categoria,
            'stock_inicial': inv.stock_inicial,
            'entradas': inv.entradas,
            'ventas': inv.ventas,
            'stock_final': inv.stock_final,
            'stock_inicial_fmt': _fmt_cantidad_ipb(inv.stock_inicial, inv.producto.unidad_medida),
            'entradas_fmt': _fmt_cantidad_ipb(inv.entradas, inv.producto.unidad_medida),
            'ventas_fmt': _fmt_cantidad_ipb(inv.ventas, inv.producto.unidad_medida),
            'stock_final_fmt': _fmt_cantidad_ipb(inv.stock_final, inv.producto.unidad_medida),
            'precio_venta': precio_venta,
            'precio_compra': costo_promedio_entrada,
            'costo_venta': costo_venta,
            'ingreso': ingreso,
            'ganancia': ganancia,
            'mix_txt': ' + '.join(mix_map.get(inv.producto.id, [])),
            'agotado': inv.stock_final == 0 and inv.ventas > 0,
            'donado': donado,
            'donado_fmt': _fmt_cantidad_ipb(donado, inv.producto.unidad_medida),
            'tiene_donacion': donado > 0,
            'en_deuda': en_deuda,
            'en_deuda_fmt': _fmt_cantidad_ipb(en_deuda, inv.producto.unidad_medida),
            'tiene_deuda': en_deuda > 0,
        })
    
    resumen_dinero = Venta.objects.filter(
        fecha_venta__date=fecha,
        cancelada=False
    ).aggregate(
        efectivo=Sum('monto_recibido'),
        transferencia=Sum('monto_transferencia'),
        cambio=Sum('cambio'),
        total_ventas=Sum('total'),
    )
    efectivo_recibido = resumen_dinero['efectivo'] or 0
    transferencia_recibida = resumen_dinero['transferencia'] or 0
    cambio_devuelto = resumen_dinero['cambio'] or 0
    total_ventas_monto = resumen_dinero['total_ventas'] or 0
    
    gastos_dia = Gasto.objects.filter(fecha_gasto__date=fecha)
    resumen_gastos = gastos_dia.aggregate(
        total=Sum(F('cantidad_efectivo') + F('cantidad_transferencia')),
        efectivo=Sum('cantidad_efectivo'),
        transferencia=Sum('cantidad_transferencia'),
    )
    total_gastos = resumen_gastos['total'] or 0
    
    total_costo_unitario = sum(float(r['precio_compra'] * r['stock_inicial']) for r in reporte)
    total_ingreso = sum(float(r['ingreso']) for r in reporte)
    total_ganancia = sum(float(r['ganancia']) for r in reporte)
    
    return {
        'fecha': fecha,
        'hoy': hoy,
        'es_hoy': fecha == hoy,
        'reporte': reporte,
        'resumen': {
            'total_productos': len(reporte),
            'total_stock_inicial': total_inicial,
            'total_entradas': total_entradas,
            'total_ventas': total_ventas,
            'total_stock_final': total_final,
            'productos_movimiento': productos_movimiento,
            'productos_sin_stock': productos_sin_stock,
            'total_ingreso': total_ingreso,
            'total_gastos': total_gastos,
            'total_recaudado': total_ventas_monto - total_gastos,
            'total_ganancia': total_ganancia,
            'total_donado': total_donado,
            'total_en_deuda': total_en_deuda,
            'productos_donados': productos_donados,
            'productos_en_deuda': productos_en_deuda,
        },
        'ahora': timezone.now(),
    }

def _registrar_movimiento(producto, tipo, cantidad, usuario=None, referencia_id=None, descripcion=''):
    """Registra un movimiento de inventario."""
    stock_anterior = producto.stock
    if tipo in ['entrada', 'devolucion']:
        producto.stock += cantidad
        cantidad_signada = abs(cantidad)
    elif tipo in ['venta', 'donacion', 'deuda']:
        producto.stock -= cantidad
        cantidad_signada = -abs(cantidad)
    elif tipo == 'ajuste':
        producto.stock = cantidad
        cantidad_signada = cantidad
    producto.save()
    MovimientoInventario.objects.create(
        producto=producto,
        tipo=tipo,
        cantidad=cantidad_signada,
        stock_anterior=stock_anterior,
        stock_nuevo=producto.stock,
        referencia_id=referencia_id,
        descripcion=descripcion,
        usuario=usuario,
    )

def _sincronizar_inventario_dia(fecha):
    """Sincroniza el inventario del día con las ventas, entradas y donaciones reales."""
    from datetime import timedelta
    from django.db.models import Sum
    
    dia_anterior = fecha - timedelta(days=1)
    
    productos = Producto.objects.filter(activo=True)
    
    ventas_dia = DetalleVenta.objects.filter(
        venta__fecha_venta__date=fecha,
        venta__cancelada=False
    ).values('producto_id').annotate(cantidad_vendida=Sum('cantidad_base'))
    ventas_map = {v['producto_id']: v['cantidad_vendida'] or 0 for v in ventas_dia}
    
    entradas_dia = EntradaProducto.objects.filter(
        fecha_entrada__date=fecha
    ).values('producto_id').annotate(cantidad_entrada=Sum('cantidad'))
    entradas_map = {e['producto_id']: e['cantidad_entrada'] or 0 for e in entradas_dia}
    
    donaciones_dia = RetiroDonacion.objects.filter(
        fecha_retiro__date=fecha
    ).values('producto_id').annotate(cantidad_donada=Sum('cantidad'))
    donaciones_map = {d['producto_id']: d['cantidad_donada'] or 0 for d in donaciones_dia}

    # Productos entregados como deuda (salida sin ingreso, igual que donación).
    # Se mide en UNIDAD BASE (cantidad_base = cantidad x factor de presentación).
    try:
        deudas_dia = Deuda.objects.filter(
            fecha_registro__date=fecha,
            tipo='producto'
        ).values('producto_id').annotate(cantidad_deuda=Sum('cantidad_base'))
        deudas_map = {d['producto_id']: deudas_dia and (d['cantidad_deuda'] or 0) for d in deudas_dia}
        # Fallback para deudas viejas (cantidad_base = 0): usar cantidad.
        deudas_old = Deuda.objects.filter(
            fecha_registro__date=fecha, tipo='producto', cantidad_base=0
        ).values('producto_id').annotate(cantidad_deuda=Sum('cantidad'))
        for d in deudas_old:
            if not deudas_map.get(d['producto_id']):
                deudas_map[d['producto_id']] = d['cantidad_deuda'] or 0
    except Exception:
        deudas_dia = Deuda.objects.filter(
            fecha_registro__date=fecha,
            tipo='producto'
        ).values('producto_id').annotate(cantidad_deuda=Sum('cantidad'))
        deudas_map = {d['producto_id']: d['cantidad_deuda'] or 0 for d in deudas_dia}
    
    for producto in productos:
        inventario_existente = InventarioDiario.objects.filter(
            fecha=fecha,
            producto=producto
        ).first()
        
        # Buscar el ÚLTIMO inventario anterior (no solo el día anterior)
        # para garantizar continuidad de stock_final → stock_inicial
        inv_anterior = InventarioDiario.objects.filter(
            fecha__lt=fecha,
            producto=producto
        ).order_by('-fecha').first()
        
        entradas = entradas_map.get(producto.id, 0)
        ventas = ventas_map.get(producto.id, 0)
        donaciones = donaciones_map.get(producto.id, 0)
        salidas_deuda = deudas_map.get(producto.id, 0)

        stock_final = producto.stock
        stock_inicial = stock_final - entradas + ventas + donaciones + salidas_deuda
        
        inventario, created = InventarioDiario.objects.get_or_create(
            fecha=fecha,
            producto=producto,
            defaults={
                'stock_inicial': stock_inicial,
                'entradas': entradas,
                'ventas': ventas,
                'stock_final': stock_final,
            }
        )
        
        if not created:
            # Si el inventario ya existía para esta fecha
            if not inventario.cerrado:
                inventario.entradas = entradas
                inventario.ventas = ventas
                inventario.stock_final = producto.stock
                inventario.stock_inicial = producto.stock - entradas + ventas + donaciones + salidas_deuda
                inventario.save()


@requiere_admin
def ipb(request):
    fecha_str = request.GET.get('fecha', '')
    hoy = ahora_servidor().date()
    
    if fecha_str:
        try:
            fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
        except ValueError:
            fecha = hoy
    else:
        fecha = hoy
    
    # No permitir ver IPB de fechas futuras
    if fecha > hoy:
        messages.error(request, 'No se puede ver el IPB de una fecha futura.')
        fecha = hoy
    
    context = _obtener_datos_ipb(fecha)
    return render(request, 'core/ipb.html', context)


@login_required
@require_POST
def pos_registrar_gasto(request):
    try:
        data = json.loads(request.body)
        cantidad_efectivo = Decimal(str(data.get('cantidad_efectivo', 0)))
        cantidad_transferencia = Decimal(str(data.get('cantidad_transferencia', 0)))
        descripcion = data.get('descripcion', '').strip()
        categoria = data.get('categoria', 'caja')

        total = cantidad_efectivo + cantidad_transferencia
        if total <= 0:
            return JsonResponse({'error': 'La cantidad debe ser mayor a 0.'}, status=400)

        turno = None
        try:
            empleado = request.user.empleado
            turno = empleado.turno_abierto
        except Empleado.DoesNotExist:
            pass

        numero_gasto = Gasto.generar_numero()
        gasto = Gasto.objects.create(
            numero_gasto=numero_gasto,
            cajero=request.user,
            turno=turno,
            cantidad_efectivo=cantidad_efectivo,
            cantidad_transferencia=cantidad_transferencia,
            categoria=categoria,
            descripcion=descripcion,
        )

        return JsonResponse({
            'success': True,
            'gasto_id': gasto.id,
            'numero_gasto': gasto.numero_gasto,
            'cantidad_efectivo': str(gasto.cantidad_efectivo),
            'cantidad_transferencia': str(gasto.cantidad_transferencia),
            'cantidad_total': str(gasto.cantidad_total),
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
def pos_mis_gastos(request):
    hoy = ahora_servidor().date()
    gastos = Gasto.objects.filter(
        cajero=request.user,
        fecha_gasto__date=hoy,
    ).order_by('-fecha_gasto')

    resumen = gastos.aggregate(
        total=Sum(F('cantidad_efectivo') + F('cantidad_transferencia')),
        efectivo=Sum('cantidad_efectivo'),
        transferencia=Sum('cantidad_transferencia'),
        cantidad=Count('id')
    )

    data = []
    for g in gastos:
        data.append({
            'id': g.id,
            'numero': g.numero_gasto,
            'cantidad_efectivo': str(g.cantidad_efectivo),
            'cantidad_transferencia': str(g.cantidad_transferencia),
            'cantidad_total': str(g.cantidad_total),
            'categoria': g.get_categoria_display(),
            'descripcion': g.descripcion or '',
            'hora': g.fecha_gasto.strftime('%H:%M'),
        })

    return JsonResponse({
        'gastos': data,
        'resumen': {
            'total': str(resumen['total'] or 0),
            'efectivo': str(resumen['efectivo'] or 0),
            'transferencia': str(resumen['transferencia'] or 0),
            'cantidad': resumen['cantidad'] or 0,
        }
    })


@requiere_admin
def venta_impresion(request, fecha=None):
    """Genera PDF de ventas del dia."""
    from datetime import timedelta
    
    if fecha:
        try:
            fecha = timezone.datetime.strptime(fecha, '%Y-%m-%d').date()
        except ValueError:
            fecha = ahora_servidor().date()
    else:
        fecha_str = request.GET.get('fecha', '')
        if fecha_str:
            try:
                fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
            except ValueError:
                fecha = ahora_servidor().date()
        else:
            fecha = ahora_servidor().date()
    
    periodo = request.GET.get('periodo', 'dia')
    empleado_filtro = request.GET.get('empleado', '')
    
    fecha_dt = timezone.make_aware(timezone.datetime.combine(fecha, timezone.datetime.min.time()))
    fd = fecha_dt
    fh = fecha_dt + timedelta(days=1)
    
    ventas = Venta.objects.filter(
        fecha_venta__gte=fd,
        fecha_venta__lt=fh,
        cancelada=False
    ).select_related('cajero', 'turno')
    
    if periodo == 'mes':
        ventas = Venta.objects.filter(
            fecha_venta__year=fecha.year,
            fecha_venta__month=fecha.month,
            cancelada=False
        ).select_related('cajero')
    elif periodo == 'ano':
        ventas = Venta.objects.filter(
            fecha_venta__year=fecha.year,
            cancelada=False
        ).select_related('cajero')
    
    if empleado_filtro:
        ventas = ventas.filter(cajero__username=empleado_filtro)
    
    try:
        ventas = ventas.prefetch_related('detalles__producto')
        ventas_list = list(ventas)
    except Exception as e:
        print(f"Error converting ventas: {e}")
        ventas_list = []
    
    monto_total = 0
    total_efectivo = 0
    total_transferencia = 0
    costo_total = 0
    total_items = 0
    ranking_map = {}

    for v in ventas_list:
        detalles = list(v.detalles.all())
        v.items_list = detalles
        v.num_items = sum(d.cantidad for d in detalles)
        costo = 0
        for d in detalles:
            precio_costo = float(d.producto.precio_compra or 0)
            costo += float(d.cantidad) * precio_costo
            total_items += d.cantidad
            r = ranking_map.get(d.producto_id)
            if r is None:
                r = ranking_map[d.producto_id] = {
                    'producto': d.producto,
                    'cantidad': 0,
                    'ingreso': 0.0,
                }
            r['cantidad'] += d.cantidad
            r['ingreso'] += float(d.subtotal)
        v.costo_venta = costo
        v.ganancia = float(v.total or 0) - costo
        costo_total += costo
        try:
            if v.total:
                monto_total += float(v.total)
            if v.monto_recibido:
                total_efectivo += float(v.monto_recibido)
            if v.monto_transferencia:
                total_transferencia += float(v.monto_transferencia)
        except Exception:
            pass

    ranking = sorted(ranking_map.values(), key=lambda x: x['ingreso'], reverse=True)
    ticket_promedio = (monto_total / len(ventas_list)) if ventas_list else 0

    context = {
        'fecha': fecha,
        'ahora': timezone.now(),
        'ventas': ventas_list,
        'monto_total': monto_total,
        'total_efectivo': total_efectivo,
        'total_transferencia': total_transferencia,
        'total_ventas': len(ventas_list),
        'ganancia_total': monto_total - costo_total,
        'ticket_promedio': ticket_promedio,
        'total_items': total_items,
        'ranking': ranking,
        'periodo': periodo,
        'empleado_filtro': empleado_filtro,
    }
    
    html_string = render_to_string('core/venta_impresion.html', context)

    buffer = BytesIO()

    _pisa = pisa
    if _pisa is None:
        try:
            from xhtml2pdf import pisa as _pisa_mod
            _pisa = _pisa_mod
        except Exception:
            return HttpResponse('PDF no disponible (falta xhtml2pdf/bidi en el servidor).', status=500)

    pisa_status = _pisa.CreatePDF(
        html_string,
        dest=buffer,
        encoding='utf-8'
    )
    
    if pisa_status.err:
        return HttpResponse('Error al generar PDF', status=500)
    
    pdf = buffer.getvalue()
    buffer.close()
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="Ventas_{fecha.strftime("%Y%m%d")}.pdf"'
    response.write(pdf)
    
    return response


@requiere_admin
def ipb_impresion(request, fecha=None):
    """Vista que genera un PDF del IPB para impresión."""
    if fecha:
        try:
            fecha = timezone.datetime.strptime(fecha, '%Y-%m-%d').date()
        except ValueError:
            fecha = ahora_servidor().date()
    else:
        fecha_str = request.GET.get('fecha', '')
        if fecha_str:
            try:
                fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
            except ValueError:
                fecha = ahora_servidor().date()
        else:
            fecha = ahora_servidor().date()
    
    _sincronizar_inventario_dia(fecha)
    context = _obtener_datos_ipb(fecha)
    
    html_string = render_to_string('core/ipb_impresion.html', context)
    
    # Crear buffer para el PDF
    buffer = BytesIO()

    # Generar PDF
    _pisa2 = pisa
    if _pisa2 is None:
        try:
            from xhtml2pdf import pisa as _pisa_mod
            _pisa2 = _pisa_mod
        except Exception:
            return HttpResponse('PDF no disponible (falta xhtml2pdf/bidi en el servidor).', status=500)
    pisa_status = _pisa2.CreatePDF(
        html_string,
        dest=buffer,
        encoding='utf-8'
    )
    
    if pisa_status.err:
        return HttpResponse('Error al generar PDF', status=500)
    
    # Preparar respuesta
    pdf = buffer.getvalue()
    buffer.close()
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="IPB_{fecha.strftime("%Y%m%d")}.pdf"'
    response.write(pdf)
    
    return response


@requiere_admin
def gasto_lista(request):
    hoy = ahora_servidor().date()
    fecha_str = request.GET.get('fecha', '')
    empleado_filtro = request.GET.get('empleado', '')
    periodo = request.GET.get('periodo', 'dia')

    if fecha_str:
        try:
            fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
        except ValueError:
            fecha = hoy
    else:
        fecha = hoy

    gastos = Gasto.objects.select_related('cajero').all()

    if periodo == 'dia':
        titulo = f'Gastos del dia {fecha.strftime("%d/%m/%Y")}'
        gastos = gastos.filter(fecha_gasto__date=fecha)
    elif periodo == 'mes':
        titulo = f'Gastos de {fecha.strftime("%B %Y")}'
        gastos = gastos.filter(fecha_gasto__year=fecha.year, fecha_gasto__month=fecha.month)
    elif periodo == 'ano':
        titulo = f'Gastos del ano {fecha.year}'
        gastos = gastos.filter(fecha_gasto__year=fecha.year)
    else:
        titulo = f'Gastos del dia {fecha.strftime("%d/%m/%Y")}'
        gastos = gastos.filter(fecha_gasto__date=fecha)

    if empleado_filtro:
        gastos = gastos.filter(cajero__username=empleado_filtro)

    resumen = gastos.aggregate(
        total=Sum(F('cantidad_efectivo') + F('cantidad_transferencia')) or 0,
        cantidad=Count('id'),
        efectivo=Sum('cantidad_efectivo'),
        transferencia=Sum('cantidad_transferencia'),
    )

    empleados = Empleado.objects.filter(activo=True).select_related('user')

    context = {
        'gastos': gastos,
        'fecha': fecha.strftime('%Y-%m-%d'),
        'periodo': periodo,
        'titulo': titulo,
        'empleado_filtro': empleado_filtro,
        'empleados': empleados,
        'resumen_total': resumen['total'] or 0,
        'resumen_cantidad': resumen['cantidad'] or 0,
        'resumen_efectivo': resumen['efectivo'] or 0,
        'resumen_transferencia': resumen['transferencia'] or 0,
        'hoy': hoy.strftime('%Y-%m-%d'),
    }
    return render(request, 'core/gasto_lista.html', context)


@requiere_admin
def gasto_crear(request):
    if request.method == 'POST':
        cantidad_efectivo = Decimal(str(request.POST.get('cantidad_efectivo', 0)))
        cantidad_transferencia = Decimal(str(request.POST.get('cantidad_transferencia', 0)))
        categoria = request.POST.get('categoria', 'caja')
        descripcion = request.POST.get('descripcion', '').strip()

        total = cantidad_efectivo + cantidad_transferencia
        if total <= 0:
            messages.error(request, 'La cantidad debe ser mayor a 0.')
            return redirect('core:gasto_crear')

        numero_gasto = Gasto.generar_numero()
        Gasto.objects.create(
            numero_gasto=numero_gasto,
            cajero=request.user,
            cantidad_efectivo=cantidad_efectivo,
            cantidad_transferencia=cantidad_transferencia,
            categoria=categoria,
            descripcion=descripcion,
        )
        messages.success(request, f'Gasto {numero_gasto} creado correctamente.')
        return redirect('core:gasto_lista')

    return render(request, 'core/gasto_form.html', {'titulo': 'Registrar Gasto'})


@requiere_admin
def gasto_editar(request, pk):
    gasto = get_object_or_404(Gasto, pk=pk)

    if request.method == 'POST':
        gasto.cantidad_efectivo = Decimal(str(request.POST.get('cantidad_efectivo', 0)))
        gasto.cantidad_transferencia = Decimal(str(request.POST.get('cantidad_transferencia', 0)))
        gasto.categoria = request.POST.get('categoria', 'caja')
        gasto.descripcion = request.POST.get('descripcion', '').strip()
        gasto.save()
        messages.success(request, f'Gasto {gasto.numero_gasto} actualizado.')
        return redirect('core:gasto_lista')

    return render(request, 'core/gasto_form.html', {'titulo': 'Editar Gasto', 'gasto': gasto})


@requiere_admin
def gasto_eliminar(request, pk):
    gasto = get_object_or_404(Gasto, pk=pk)
    if request.method == 'POST':
        numero = gasto.numero_gasto
        gasto.delete()
        messages.success(request, f'Gasto {numero} eliminado.')
        return redirect('core:gasto_lista')
    return render(request, 'core/gasto_confirmar_eliminar.html', {'gasto': gasto})


@requiere_admin
def entrada_lista(request):
    hoy = ahora_servidor().date()
    fecha_str = request.GET.get('fecha', '')
    
    if fecha_str:
        try:
            fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
        except ValueError:
            fecha = hoy
    else:
        fecha = hoy

    entradas = EntradaProducto.objects.filter(fecha_entrada__date=fecha).select_related('producto').order_by('-fecha_entrada')
    
    resumen = entradas.aggregate(
        total=Sum('costo_total'),
        cantidad=Count('id'),
    )

    context = {
        'entradas': entradas,
        'fecha': fecha.strftime('%Y-%m-%d'),
        'resumen_total': float(resumen['total'] or 0),
        'resumen_cantidad': resumen['cantidad'] or 0,
    }
    return render(request, 'core/entrada_lista.html', context)


@requiere_admin
def entrada_crear(request):
    productos = Producto.objects.filter(activo=True).select_related('categoria').order_by('nombre')
    
    if request.method == 'POST':
        producto_id = request.POST.get('producto')
        try:
            cantidad = Decimal(str(request.POST.get('cantidad', '0')))
        except Exception:
            cantidad = Decimal('0')
        costo_unitario = Decimal(request.POST.get('costo_unitario', '0'))
        proveedor = request.POST.get('proveedor', '').strip()
        descripcion = request.POST.get('descripcion', '').strip()

        if not producto_id or cantidad <= 0:
            messages.error(request, 'Seleccione un producto y cantidad mayor a 0 (admite 3 decimales, ej. 2.500 lb).')
            return redirect('core:entrada_crear')

        producto = Producto.objects.get(pk=producto_id)
        numero_entrada = EntradaProducto.generar_numero()
        
        costo_unitario_dec = Decimal(request.POST.get('costo_unitario', '0'))
        
        if costo_unitario_dec > Decimal('0'):
            producto.precio_compra = costo_unitario_dec
            producto.save()
            producto.refresh_from_db()
        
        entrada = EntradaProducto.objects.create(
            numero_entrada=numero_entrada,
            producto=producto,
            cantidad=cantidad,
            costo_unitario=costo_unitario_dec,
            proveedor=proveedor,
            descripcion=descripcion,
        )
        
        _registrar_movimiento(producto, 'entrada', cantidad, request.user, entrada.id, f'Entrada #{numero_entrada}')

        _sincronizar_inventario_dia(ahora_servidor().date())

        messages.success(request, f'Entrada {numero_entrada} registrada. {"%g" % float(cantidad)} {producto.unidad_medida} agregados a {producto.nombre}.')
        return redirect('core:entrada_lista')

    return render(request, 'core/entrada_form.html', {'productos': productos})


@requiere_admin
def entrada_eliminar(request, pk):
    entrada = get_object_or_404(EntradaProducto, pk=pk)
    if request.method == 'POST':
        numero = entrada.numero_entrada
        producto = entrada.producto
        cantidad = entrada.cantidad
        
        # Revertir efectos en el producto (descontar stock)
        if producto.stock >= cantidad:
            producto.stock -= cantidad
            producto.save()
        else:
            messages.error(request, f'No se puede eliminar. Stock actual ({producto.stock}) menor que cantidad de entrada ({cantidad}).')
            return redirect('core:entrada_lista')
        
        # Eliminar movimiento de inventario relacionado
        MovimientoInventario.objects.filter(
            producto=producto,
            referencia_id=entrada.id,
            tipo='entrada'
        ).delete()
        
        # Eliminar la entrada
        entrada.delete()
        
        # Recalcular inventario diario
        _sincronizar_inventario_dia(entrada.fecha_entrada.date())
        
        messages.success(request, f'Entrada {numero} eliminada. Se revirtieron {cantidad} unidades del stock de {producto.nombre}.')
        return redirect('core:entrada_lista')
    
    return render(request, 'core/entrada_confirmar_eliminar.html', {'entrada': entrada})


# ============================================================
# RETIROS POR DONACIÓN
# ============================================================

@requiere_admin
def retiro_donacion_lista(request):
    hoy = ahora_servidor().date()
    fecha_str = request.GET.get('fecha', '')

    if fecha_str:
        try:
            fecha = timezone.datetime.strptime(fecha_str, '%Y-%m-%d').date()
        except ValueError:
            fecha = hoy
    else:
        fecha = hoy

    retiros = RetiroDonacion.objects.filter(
        fecha_retiro__date=fecha
    ).select_related('producto', 'beneficiario', 'registrado_por').order_by('-fecha_retiro')

    q = request.GET.get('q', '').strip()
    if q:
        retiros = retiros.filter(
            Q(producto__nombre__icontains=q) | Q(producto__codigo__icontains=q)
            | Q(motivo__icontains=q)
            | Q(beneficiario__first_name__icontains=q) | Q(beneficiario__last_name__icontains=q)
            | Q(beneficiario__username__icontains=q)
        )

    resumen = retiros.aggregate(
        total=Sum('producto__precio_venta'),
        cantidad=Sum('cantidad'),
    )

    context = {
        'retiros': retiros,
        'fecha': fecha.strftime('%Y-%m-%d'),
        'q': q,
        'resumen_total': float(resumen['total'] or 0),
        'resumen_cantidad': resumen['cantidad'] or 0,
    }
    return render(request, 'core/retiro_donacion_lista.html', context)


@requiere_admin
def retiro_donacion_crear(request):
    productos = Producto.objects.filter(activo=True, stock__gt=0).select_related('categoria').order_by('categoria__nombre', 'nombre')

    if request.method == 'POST':
        beneficiario_nombre = request.POST.get('beneficiario_nombre', '').strip()
        motivo = request.POST.get('motivo', '').strip()
        
        # El POS llama por fetch: responde JSON en vez de redirect con messages.
        es_json = request.headers.get('X-Requested-With') == 'XMLHttpRequest'
        productos_data = request.POST.get('productos_data', '')
        if not productos_data:
            if es_json:
                return JsonResponse({'ok': False, 'error': 'Seleccione al menos un producto.'}, status=400)
            messages.error(request, 'Seleccione al menos un producto.')
            return redirect('core:retiro_donacion_crear')

        try:
            items = json.loads(productos_data)
        except json.JSONDecodeError:
            if es_json:
                return JsonResponse({'ok': False, 'error': 'Datos de productos inválidos.'}, status=400)
            messages.error(request, 'Datos de productos inválidos.')
            return redirect('core:retiro_donacion_crear')

        if not items:
            if es_json:
                return JsonResponse({'ok': False, 'error': 'Seleccione al menos un producto con cantidad mayor a 0.'}, status=400)
            messages.error(request, 'Seleccione al menos un producto con cantidad mayor a 0.')
            return redirect('core:retiro_donacion_crear')

        if not beneficiario_nombre:
            beneficiario_nombre = request.POST.get('beneficiario_select', '').strip()
            if beneficiario_nombre:
                try:
                    beneficiario_user = User.objects.get(pk=beneficiario_nombre)
                    beneficiario_nombre = beneficiario_user.get_full_name() or beneficiario_user.username
                except User.DoesNotExist:
                    pass
        
        if not beneficiario_nombre:
            beneficiario_nombre = 'Sin especificar'

        total_unidades = 0
        retiros_creados = []
        advertencias = []

        beneficiario_user = User.objects.filter(username='sistema').first() or User.objects.filter(is_superuser=True).first()

        for item in items:
            producto_id = item.get('producto_id')
            try:
                cantidad = Decimal(str(item.get('cantidad', '0')))
            except Exception:
                continue
            
            if cantidad <= 0 or not producto_id:
                continue
                
            try:
                producto = Producto.objects.get(pk=producto_id, activo=True)
            except Producto.DoesNotExist:
                continue
                
            if cantidad > producto.stock:
                w = f'Stock insuficiente para {producto.nombre}. Disponible: {producto.stock}'
                advertencias.append(w)
                messages.warning(request, w)
                continue

            numero_retiro = RetiroDonacion.generar_numero()
            
            retiro = RetiroDonacion.objects.create(
                numero_retiro=numero_retiro,
                producto=producto,
                cantidad=cantidad,
                beneficiario=beneficiario_user,
                registrado_por=request.user,
                motivo=f"{motivo} - Beneficiario: {beneficiario_nombre}" if motivo else beneficiario_nombre,
            )

            _registrar_movimiento(producto, 'donacion', cantidad, request.user, retiro.id, f'Donación #{numero_retiro}')
            
            total_unidades += cantidad
            retiros_creados.append(f"{producto.nombre} x{cantidad}")

        if retiros_creados:
            _sincronizar_inventario_dia(ahora_servidor().date())

            msg = f"Donación registrada para {beneficiario_nombre}: "
            msg += ", ".join(retiros_creados[:3])
            if len(retiros_creados) > 3:
                msg += f" y {len(retiros_creados) - 3} más"
            if es_json:
                return JsonResponse({'ok': True, 'message': msg,
                                     'count': len(retiros_creados),
                                     'warnings': advertencias})
            messages.success(request, msg)
        else:
            if es_json:
                return JsonResponse({'ok': False,
                                     'error': 'No se pudieron registrar las donaciones.',
                                     'warnings': advertencias}, status=400)
            messages.error(request, 'No se pudieron registrar las donaciones.')

        return redirect('core:retiro_donacion_lista')

    return render(request, 'core/retiro_donacion_form.html', {
        'productos': productos,
    })


@requiere_admin
def retiro_donacion_eliminar(request, pk):
    retiro = get_object_or_404(RetiroDonacion, pk=pk)
    if request.method == 'POST':
        numero = retiro.numero_retiro
        producto = retiro.producto
        cantidad = retiro.cantidad

        producto.stock += cantidad
        producto.save()
        
        _sincronizar_inventario_dia(ahora_servidor().date())

        messages.success(request, f'Donación {numero} eliminada. Stock restaurado.')
        return redirect('core:retiro_donacion_lista')
    return render(request, 'core/retiro_donacion_confirmar.html', {'retiro': retiro})


@requiere_admin
def submayor_lista(request):
    productos = Producto.objects.filter(activo=True).select_related('categoria').order_by('nombre')
    return render(request, 'core/submayor_lista.html', {'productos': productos})


@requiere_admin
def submayor_detalle(request, producto_id):
    producto = get_object_or_404(Producto.objects.select_related('categoria'), pk=producto_id)
    
    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    
    hoy = ahora_servidor().date()
    if not fecha_inicio:
        fecha_inicio = (hoy - timedelta(days=30)).strftime('%Y-%m-%d')
    if not fecha_fin:
        fecha_fin = hoy.strftime('%Y-%m-%d')
    
    movimientos = MovimientoInventario.objects.filter(
        producto=producto,
        fecha__date__gte=fecha_inicio,
        fecha__date__lte=fecha_fin
    ).order_by('-fecha')
    
    context = {
        'producto': producto,
        'movimientos': movimientos,
        'fecha_inicio': fecha_inicio,
        'fecha_fin': fecha_fin,
    }
    return render(request, 'core/submayor_detalle.html', context)


# ============================================================
# DEUDORES Y DEUDAS
# ============================================================

def _resumen_deuda(deuda):
    """Calcula abonado/saldo de una deuda (aprovecha abonos prefetcheados)."""
    abonado = sum((a.monto for a in deuda.abonos.all()), Decimal('0'))
    deuda.calc_abonado = abonado
    deuda.calc_saldo = deuda.monto - abonado
    deuda.calc_pagada = deuda.calc_saldo <= 0
    return deuda


def saldo_deudor(deudor):
    return sum((_resumen_deuda(d).calc_saldo for d in deudor.deudas.all()), Decimal('0'))


def _aplicar_abono_deudor(deudor, monto, metodo, nota, usuario):
    """Liquida: distribuye el pago entre las deudas pendientes (más antiguas primero)."""
    monto = Decimal(str(monto))
    if monto <= 0:
        raise ValueError('El monto debe ser mayor a 0.')
    deudas = list(Deuda.objects.filter(deudor=deudor).prefetch_related('abonos').order_by('fecha_registro', 'id'))
    for d in deudas:
        _resumen_deuda(d)
    saldo_total = sum((d.calc_saldo for d in deudas if d.calc_saldo > 0), Decimal('0'))
    if monto > saldo_total:
        raise ValueError(f'El monto supera el saldo pendiente (${saldo_total}).')
    aplicados = []
    restante = monto
    for d in deudas:
        if restante <= 0:
            break
        if d.calc_saldo <= 0:
            continue
        parte = min(d.calc_saldo, restante)
        AbonoDeuda.objects.create(
            deuda=d, monto=parte, metodo=metodo,
            nota=nota or '', registrada_por=usuario,
        )
        aplicados.append({'deuda': d, 'monto': parte})
        restante -= parte
    return aplicados


def _crear_deuda(deudor, tipo, usuario, monto=None, producto=None, cantidad=1, motivo='', fecha_pago=None, presentacion=None, presentacion_id=None):
    """Crea una deuda de dinero o de producto (descuenta stock y lo valoriza a precio de la PRESENTACIÓN).

    Presentaciones: un cartón de huevo no vale lo mismo que un huevo suelto.
    - cantidad: unidades DE LA PRESENTACIÓN (ej. 1 cartón).
    - cantidad_base = cantidad x factor (unidades base que salen del stock).
    - monto = cantidad x precio manual de la presentación.
    """
    from .models import PresentacionProducto

    def _fmt_cant(v):
        try:
            c = Decimal(str(v))
            s = format(c.quantize(Decimal('0.001')).normalize(), 'f')
            return s
        except Exception:
            return str(v)

    try:
        cantidad = Decimal(str(cantidad or 1))
    except Exception:
        cantidad = Decimal('1')
    cantidad = cantidad.quantize(Decimal('0.001'))
    if tipo == 'producto':
        if producto is None:
            raise ValueError('Seleccione el producto a entregar.')
        if cantidad <= 0:
            raise ValueError('Cantidad inválida.')
        # Resolver presentación: la elegida, si no la default del producto.
        pres = presentacion
        if pres is None and presentacion_id:
            try:
                pres = PresentacionProducto.objects.get(
                    pk=presentacion_id, producto=producto, activo=True)
            except PresentacionProducto.DoesNotExist:
                pres = None
        if pres is None:
            pres = producto.presentacion_default()
        factor = pres.factor if pres else Decimal('1')
        precio = pres.precio if pres else producto.precio_venta
        if not producto.permite_decimal and cantidad != cantidad.to_integral_value():
            raise ValueError(f'{producto.nombre} solo admite unidades enteras.')
        cantidad_base = (cantidad * factor).quantize(Decimal('0.001'))
        if cantidad_base <= 0:
            raise ValueError('Cantidad inválida.')
        if cantidad_base > producto.stock:
            raise ValueError(
                f'Stock insuficiente de {producto.nombre}. Disponible: {("%g" % float(producto.stock))} {producto.unidad_medida}')
        monto = (precio * cantidad).quantize(Decimal('0.01'))
        extra = (motivo or '').strip()
        pres_txt = pres.nombre if pres else 'Unidad'
        auto = f"{_fmt_cant(cantidad)} x {pres_txt} - {producto.nombre}"
        motivo = f"{auto} - {extra}" if extra else auto
    else:
        monto = Decimal(str(monto or 0))
        if monto <= 0:
            raise ValueError('El monto debe ser mayor a 0.')
        precio = Decimal('0')
        pres = None
        cantidad_base = Decimal('0')
        cantidad = Decimal('1')
    deuda = Deuda.objects.create(
        numero_deuda=Deuda.generar_numero(),
        deudor=deudor,
        tipo=tipo,
        producto=producto if tipo == 'producto' else None,
        presentacion=pres if tipo == 'producto' else None,
        cantidad=cantidad if tipo == 'producto' else 1,
        cantidad_base=cantidad_base if tipo == 'producto' else 0,
        precio_unitario=precio,
        monto=monto,
        motivo=(motivo or '').strip(),
        fecha_pago=fecha_pago,
        registrada_por=usuario,
    )
    if tipo == 'producto':
        _registrar_movimiento(
            producto, 'deuda', cantidad_base, usuario, deuda.id,
            f'Deuda #{deuda.numero_deuda} - {deudor.nombre_completo}'
        )
        _sincronizar_inventario_dia(ahora_servidor().date())
    return deuda


def _parse_fecha_pago(valor):
    valor = (valor or '').strip()
    if not valor:
        return None
    try:
        return timezone.datetime.strptime(valor, '%Y-%m-%d').date()
    except ValueError:
        return None


@login_required
def deuda_lista(request):
    q = request.GET.get('q', '').strip()
    pendientes_only = request.GET.get('pendientes') == '1'

    deudores = Deudor.objects.prefetch_related('deudas__abonos').order_by('nombre', 'apellido')
    if q:
        deudores = deudores.filter(
            Q(nombre__icontains=q) | Q(apellido__icontains=q) | Q(ci__icontains=q)
        )
    deudores = list(deudores)
    for d in deudores:
        d.calc_saldo = saldo_deudor(d)
        d.calc_pendientes = sum(1 for deuda in d.deudas.all() if _resumen_deuda(deuda).calc_saldo > 0)

    deudas = Deuda.objects.select_related('deudor', 'producto', 'presentacion').prefetch_related('abonos').order_by('-fecha_registro')
    if pendientes_only:
        deudas = [d for d in deudas if _resumen_deuda(d).calc_saldo > 0]
    else:
        deudas = [_resumen_deuda(d) for d in deudas]

    total_por_cobrar = sum((d.calc_saldo for d in Deuda.objects.prefetch_related('abonos').all() if _resumen_deuda(d).calc_saldo > 0), Decimal('0'))
    total_cobrado = AbonoDeuda.objects.aggregate(total=Sum('monto'))['total'] or Decimal('0')

    context = {
        'deudores': deudores,
        'deudas': deudas,
        'total_por_cobrar': total_por_cobrar,
        'total_cobrado': total_cobrado,
        'total_deudores': Deudor.objects.filter(activo=True).count(),
        'q': q,
        'pendientes_only': pendientes_only,
    }
    return render(request, 'core/deuda_lista.html', context)


@login_required
def deudor_crear(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        apellido = request.POST.get('apellido', '').strip()
        ci = request.POST.get('ci', '').strip() or None
        telefono = request.POST.get('telefono', '').strip()

        if not nombre:
            messages.error(request, 'El nombre es requerido.')
            return redirect('core:deudor_crear')
        if not ci:
            messages.error(request, 'La CI es requerida.')
            return redirect('core:deudor_crear')
        if Deudor.objects.filter(ci=ci).exists():
            messages.error(request, 'Ya existe un deudor con esa CI.')
            return redirect('core:deudor_crear')

        deudor = Deudor.objects.create(nombre=nombre, apellido=apellido, ci=ci, telefono=telefono)
        messages.success(request, f'Deudor {deudor.nombre_completo} registrado.')
        return redirect('core:deudor_detalle', pk=deudor.pk)

    return render(request, 'core/deudor_form.html', {'titulo': 'Registrar Deudor'})


@login_required
def deudor_editar(request, pk):
    deudor = get_object_or_404(Deudor, pk=pk)

    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        apellido = request.POST.get('apellido', '').strip()
        ci = request.POST.get('ci', '').strip() or None
        telefono = request.POST.get('telefono', '').strip()

        if not nombre:
            messages.error(request, 'El nombre es requerido.')
            return redirect('core:deudor_editar', pk=pk)
        if not ci:
            messages.error(request, 'La CI es requerida.')
            return redirect('core:deudor_editar', pk=pk)
        if Deudor.objects.filter(ci=ci).exclude(pk=pk).exists():
            messages.error(request, 'Ya existe otro deudor con esa CI.')
            return redirect('core:deudor_editar', pk=pk)

        deudor.nombre = nombre
        deudor.apellido = apellido
        deudor.ci = ci
        deudor.telefono = telefono
        deudor.save()
        messages.success(request, 'Deudor actualizado.')
        return redirect('core:deudor_detalle', pk=pk)

    return render(request, 'core/deudor_form.html', {'titulo': 'Editar Deudor', 'deudor': deudor})


@login_required
def deudor_detalle(request, pk):
    deudor = get_object_or_404(Deudor.objects.prefetch_related('deudas__abonos', 'deudas__producto', 'deudas__presentacion'), pk=pk)
    deudas = sorted(deudor.deudas.all(), key=lambda d: d.fecha_registro, reverse=True)
    for d in deudas:
        _resumen_deuda(d)
    abonos = AbonoDeuda.objects.filter(deuda__deudor=deudor).select_related('deuda').order_by('-fecha')
    saldo = sum((d.calc_saldo for d in deudas), Decimal('0'))
    context = {
        'deudor': deudor,
        'deudas': deudas,
        'abonos': abonos,
        'saldo': saldo,
    }
    return render(request, 'core/deudor_detalle.html', context)


@login_required
def deudor_toggle(request, pk):
    deudor = get_object_or_404(Deudor, pk=pk)
    deudor.activo = not deudor.activo
    deudor.save()
    estado = 'activado' if deudor.activo else 'desactivado'
    messages.success(request, f'Deudor {estado}.')
    return redirect('core:deuda_lista')


@login_required
def deudor_abonar(request, pk):
    """Liquida saldo del deudor repartiendo el pago en las deudas más antiguas."""
    deudor = get_object_or_404(Deudor, pk=pk)
    if request.method == 'POST':
        try:
            aplicados = _aplicar_abono_deudor(
                deudor,
                request.POST.get('monto', '0'),
                request.POST.get('metodo', 'efectivo'),
                request.POST.get('nota', ''),
                request.user,
            )
            total = sum((a['monto'] for a in aplicados), Decimal('0'))
            messages.success(request, f'Abono de ${total} aplicado a {len(aplicados)} deuda(s) de {deudor.nombre_completo}.')
        except (ValueError, ArithmeticError) as e:
            messages.error(request, str(e))
    return redirect('core:deudor_detalle', pk=pk)


@login_required
def deudor_eliminar(request, pk):
    deudor = get_object_or_404(Deudor, pk=pk)
    if request.method == 'POST':
        if deudor.deudas.exists():
            messages.error(request, 'No se puede eliminar: el deudor tiene deudas registradas. Desactívelo en su lugar.')
            return redirect('core:deudor_detalle', pk=pk)
        nombre = deudor.nombre_completo
        deudor.delete()
        messages.success(request, f'Deudor {nombre} eliminado.')
        return redirect('core:deuda_lista')
    return render(request, 'core/deudor_confirmar_eliminar.html', {'deudor': deudor})


@login_required
def deuda_crear(request):
    if request.method == 'POST':
        try:
            from .models import PresentacionProducto
            deudor = get_object_or_404(Deudor, pk=request.POST.get('deudor'))
            tipo = request.POST.get('tipo', 'dinero')
            motivo_base = request.POST.get('motivo', '')
            fecha_pago = _parse_fecha_pago(request.POST.get('fecha_pago', ''))
            if tipo == 'producto':
                # Multiproducto: una deuda por línea (mismo patrón que donaciones).
                # Todo o nada: si una línea falla (stock, presentación), no se crea ninguna.
                try:
                    items = json.loads(request.POST.get('productos_data') or '[]')
                except (json.JSONDecodeError, TypeError):
                    raise ValueError('Datos de productos inválidos.')
                items = [it for it in items if it]
                if not items:
                    raise ValueError('Agregue al menos un producto a la deuda.')
                creadas = []
                with transaction.atomic():
                    for it in items:
                        producto = get_object_or_404(Producto, pk=it.get('producto_id'))
                        pres_id = it.get('presentacion_id') or None
                        if pres_id and not PresentacionProducto.objects.filter(
                                pk=pres_id, producto=producto, activo=True).exists():
                            raise ValueError(f'Presentación inválida para {producto.nombre}.')
                        deuda = _crear_deuda(
                            deudor=deudor,
                            tipo='producto',
                            usuario=request.user,
                            producto=producto,
                            cantidad=it.get('cantidad', 1),
                            motivo=motivo_base,
                            fecha_pago=fecha_pago,
                            presentacion_id=pres_id,
                        )
                        creadas.append(deuda)
                total = sum((d.monto for d in creadas), Decimal('0'))
                nums = ', '.join(d.numero_deuda for d in creadas[:3])
                if len(creadas) > 3:
                    nums += f' y {len(creadas) - 3} más'
                messages.success(
                    request,
                    f'{len(creadas)} deuda(s) de productos para {deudor.nombre_completo} '
                    f'(total ${total:.2f}): {nums}.'
                )
            else:
                deuda = _crear_deuda(
                    deudor=deudor,
                    tipo=tipo,
                    usuario=request.user,
                    monto=request.POST.get('monto', '0'),
                    motivo=motivo_base,
                    fecha_pago=fecha_pago,
                )
                messages.success(request, f'Deuda {deuda.numero_deuda} registrada para {deudor.nombre_completo} (${deuda.monto}).')
            return redirect('core:deudor_detalle', pk=deudor.pk)
        except ValueError as e:
            messages.error(request, str(e))
            return redirect('core:deuda_crear')

    deudores = Deudor.objects.filter(activo=True).order_by('nombre', 'apellido')
    productos = Producto.objects.filter(activo=True, stock__gt=0).prefetch_related('presentaciones').order_by('nombre')
    preselect = request.GET.get('deudor', '')
    return render(request, 'core/deuda_form.html', {
        'titulo': 'Registrar Deuda',
        'deudores': deudores,
        'productos': productos,
        'preselect': preselect,
    })


@login_required
def deuda_editar(request, pk):
    deuda = get_object_or_404(Deuda.objects.select_related('deudor', 'producto').prefetch_related('abonos'), pk=pk)
    _resumen_deuda(deuda)

    if request.method == 'POST':
        deuda.motivo = request.POST.get('motivo', '').strip()
        deuda.fecha_pago = _parse_fecha_pago(request.POST.get('fecha_pago', ''))
        if deuda.tipo == 'dinero' and deuda.calc_abonado <= 0:
            try:
                monto = Decimal(str(request.POST.get('monto', '0')))
                if monto <= 0:
                    raise ValueError('El monto debe ser mayor a 0.')
                deuda.monto = monto
            except (ValueError, ArithmeticError) as e:
                messages.error(request, str(e))
                return redirect('core:deuda_editar', pk=pk)
        deuda.save()
        messages.success(request, 'Deuda actualizada.')
        return redirect('core:deudor_detalle', pk=deuda.deudor.pk)

    return render(request, 'core/deuda_form.html', {
        'titulo': 'Editar Deuda',
        'deuda': deuda,
    })


@login_required
def deuda_abonar(request, pk):
    deuda = get_object_or_404(Deuda.objects.select_related('deudor').prefetch_related('abonos'), pk=pk)
    _resumen_deuda(deuda)

    if request.method == 'POST':
        try:
            monto = Decimal(str(request.POST.get('monto', '0')))
            metodo = request.POST.get('metodo', 'efectivo')
            nota = request.POST.get('nota', '').strip()
            if monto <= 0:
                raise ValueError('El monto debe ser mayor a 0.')
            if monto > deuda.calc_saldo:
                raise ValueError(f'El monto supera el saldo pendiente (${deuda.calc_saldo}).')
            AbonoDeuda.objects.create(
                deuda=deuda, monto=monto, metodo=metodo,
                nota=nota, registrada_por=request.user,
            )
            messages.success(request, f'Abono de ${monto} registrado.')
            return redirect('core:deudor_detalle', pk=deuda.deudor.pk)
        except (ValueError, ArithmeticError) as e:
            messages.error(request, str(e))
            return redirect('core:deuda_abonar', pk=pk)

    return render(request, 'core/deuda_abonar.html', {'deuda': deuda})


@login_required
def deuda_eliminar(request, pk):
    deuda = get_object_or_404(Deuda.objects.select_related('deudor'), pk=pk)
    if request.method == 'POST':
        if deuda.abonos.exists():
            messages.error(request, 'No se puede eliminar: la deuda tiene abonos registrados.')
            return redirect('core:deudor_detalle', pk=deuda.deudor.pk)
        numero = deuda.numero_deuda
        deudor_pk = deuda.deudor.pk
        deuda.delete()
        messages.success(request, f'Deuda {numero} eliminada.')
        return redirect('core:deudor_detalle', pk=deudor_pk)
    return render(request, 'core/deuda_confirmar_eliminar.html', {'deuda': deuda})


# ============================================================
# POS - DEUDORES Y DEUDAS (solo online)
# ============================================================

@login_required
def pos_deudores(request):
    q = request.GET.get('q', '').strip()
    deudores = Deudor.objects.filter(activo=True).prefetch_related('deudas__abonos').order_by('nombre', 'apellido')
    if q:
        deudores = deudores.filter(
            Q(nombre__icontains=q) | Q(apellido__icontains=q) | Q(ci__icontains=q)
        )[:30]
    else:
        deudores = deudores[:30]
    data = []
    for d in deudores:
        data.append({
            'id': d.id,
            'nombre': d.nombre,
            'apellido': d.apellido,
            'nombre_completo': d.nombre_completo,
            'ci': d.ci or '',
            'telefono': d.telefono or '',
            'saldo': str(saldo_deudor(d)),
        })
    return JsonResponse({'deudores': data})


@login_required
def pos_deudor_detalle(request, pk):
    deudor = get_object_or_404(Deudor.objects.prefetch_related('deudas__abonos', 'deudas__producto', 'deudas__presentacion'), pk=pk)
    deudas = sorted(deudor.deudas.all(), key=lambda d: (d.fecha_registro, d.id))
    items = []
    for d in deudas:
        _resumen_deuda(d)
        if d.calc_saldo <= 0:
            continue
        try:
            pres_nombre = d.presentacion.nombre if d.presentacion_id and d.presentacion else ''
        except Exception:
            pres_nombre = ''
        items.append({
            'id': d.id,
            'numero': d.numero_deuda,
            'tipo': d.tipo,
            'motivo': d.motivo_display,
            'presentacion': pres_nombre,
            'monto': str(d.monto),
            'abonado': str(d.calc_abonado),
            'saldo': str(d.calc_saldo),
            'fecha': d.fecha_registro.strftime('%d/%m/%Y'),
        })
    return JsonResponse({
        'id': deudor.id,
        'nombre_completo': deudor.nombre_completo,
        'ci': deudor.ci or '',
        'saldo': str(sum((Decimal(i['saldo']) for i in items), Decimal('0'))),
        'deudas': items,
    })


@login_required
@require_POST
def pos_deudor_crear(request):
    try:
        data = json.loads(request.body)
        nombre = (data.get('nombre') or '').strip()
        apellido = (data.get('apellido') or '').strip()
        ci = (data.get('ci') or '').strip()
        telefono = (data.get('telefono') or '').strip()
        if not nombre:
            return JsonResponse({'error': 'El nombre es requerido.'}, status=400)
        if not ci:
            return JsonResponse({'error': 'La CI es requerida.'}, status=400)
        if Deudor.objects.filter(ci=ci).exists():
            return JsonResponse({'error': 'Ya existe un deudor con esa CI.'}, status=400)
        deudor = Deudor.objects.create(nombre=nombre, apellido=apellido, ci=ci, telefono=telefono)
        return JsonResponse({
            'success': True,
            'id': deudor.id,
            'nombre_completo': deudor.nombre_completo,
            'ci': deudor.ci,
            'saldo': '0',
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
@require_POST
def pos_deuda_crear(request):
    try:
        data = json.loads(request.body)
        deudor = get_object_or_404(Deudor, pk=data.get('deudor_id'))
        tipo = data.get('tipo', 'dinero')
        if tipo not in ('dinero', 'producto'):
            return JsonResponse({'error': 'Tipo de deuda inválido.'}, status=400)
        from .models import PresentacionProducto
        motivo_base = data.get('motivo', '')
        fecha_pago = _parse_fecha_pago(data.get('fecha_pago', ''))
        if tipo == 'producto':
            # Multiproducto: lista de líneas; compat con línea única anterior.
            raw_items = data.get('items')
            if raw_items:
                items = [it for it in raw_items if it]
            else:
                items = [{'producto_id': data.get('producto_id'),
                          'presentacion_id': data.get('presentacion_id'),
                          'cantidad': data.get('cantidad', 1)}]
            if not items:
                return JsonResponse({'error': 'Agregue al menos un producto.'}, status=400)
            # Pre-validación (sin escribir nada todavía).
            for it in items:
                producto = get_object_or_404(Producto, pk=it.get('producto_id'))
                pres_id = it.get('presentacion_id') or None
                if pres_id and not PresentacionProducto.objects.filter(
                        pk=pres_id, producto=producto, activo=True).exists():
                    return JsonResponse(
                        {'error': f'Presentación inválida para {producto.nombre}.'}, status=400)
            creadas = []
            with transaction.atomic():
                try:
                    for it in items:
                        producto = get_object_or_404(Producto, pk=it.get('producto_id'))
                        creadas.append(_crear_deuda(
                            deudor=deudor,
                            tipo='producto',
                            usuario=request.user,
                            producto=producto,
                            cantidad=it.get('cantidad', 1),
                            motivo=motivo_base,
                            fecha_pago=fecha_pago,
                            presentacion_id=it.get('presentacion_id') or None,
                        ))
                except ValueError as e:
                    transaction.set_rollback(True)
                    return JsonResponse({'error': str(e)}, status=400)
            total = sum((d.monto for d in creadas), Decimal('0'))
            deuda = creadas[0]
            extra_resp = {
                'numeros': [d.numero_deuda for d in creadas],
                'count': len(creadas),
                'monto': str(total),
            }
        else:
            try:
                deuda = _crear_deuda(
                    deudor=deudor,
                    tipo=tipo,
                    usuario=request.user,
                    monto=data.get('monto', '0'),
                    motivo=motivo_base,
                    fecha_pago=fecha_pago,
                )
            except ValueError as e:
                return JsonResponse({'error': str(e)}, status=400)
            extra_resp = {}
        resp = {
            'success': True,
            'numero': deuda.numero_deuda,
            'monto': str(deuda.monto if tipo == 'dinero' else total),
            'motivo': deuda.motivo_display,
            'saldo_deudor': str(saldo_deudor(deudor)),
        }
        resp.update(extra_resp)
        return JsonResponse(resp)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
@require_POST
def pos_deuda_abonar(request):
    """Liquida: selecciona al deudor y reduce su saldo (reparte en las más antiguas)."""
    try:
        data = json.loads(request.body)
        deudor = get_object_or_404(Deudor, pk=data.get('deudor_id'))
        metodo = data.get('metodo', 'efectivo')
        nota = (data.get('nota') or '').strip()
        try:
            aplicados = _aplicar_abono_deudor(deudor, data.get('monto', '0'), metodo, nota, request.user)
        except ValueError as e:
            return JsonResponse({'error': str(e)}, status=400)
        return JsonResponse({
            'success': True,
            'aplicados': [{'numero': a['deuda'].numero_deuda, 'monto': str(a['monto'])} for a in aplicados],
            'saldo_deudor': str(saldo_deudor(deudor)),
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@requiere_admin
def ajuste_inventario(request):
    MOTIVOS = [
        ('inventario_fisico', 'Inventario Físico'),
        ('mercancia_danada', 'Mercancía Dañada'),
        ('mercancia_perdida', 'Mercancía Perdida'),
        ('ajuste_error', 'Ajuste por Error'),
        ('otro', 'Otro'),
    ]
    
    if request.method == 'POST':
        producto_id = request.POST.get('producto')
        motivo = request.POST.get('motivo')
        observacion = request.POST.get('observacion', '')

        producto = get_object_or_404(Producto, pk=producto_id)
        try:
            nuevo_stock = Decimal(str(request.POST.get('nuevo_stock', '')).replace(',', '.')).quantize(Decimal('0.001'))
        except Exception:
            messages.error(request, 'Nuevo stock inválido.')
            return redirect('core:ajuste_inventario')
        if nuevo_stock < 0:
            messages.error(request, 'El stock no puede ser negativo.')
            return redirect('core:ajuste_inventario')
        # Unidades enteras salvo peso (kg/lb) que admite decimales.
        if producto.unidad_medida not in ('kg', 'lb') and nuevo_stock != nuevo_stock.to_integral_value():
            messages.error(request, f'{producto.nombre} solo admite unidades enteras.')
            return redirect('core:ajuste_inventario')
        stock_anterior = producto.stock
        diferencia = nuevo_stock - stock_anterior
        
        producto.stock = nuevo_stock
        producto.save()
        
        MovimientoInventario.objects.create(
            producto=producto,
            tipo='ajuste',
            cantidad=diferencia,
            stock_anterior=stock_anterior,
            stock_nuevo=nuevo_stock,
            descripcion=f"{dict(MOTIVOS).get(motivo, motivo)} - {observacion}",
            usuario=request.user,
        )
        
        hoy = ahora_servidor().date()
        inventario_hoy = InventarioDiario.objects.filter(
            fecha=hoy,
            producto=producto
        ).first()
        
        if inventario_hoy:
            inventario_hoy.stock_inicial = nuevo_stock
            inventario_hoy.stock_final = inventario_hoy.stock_inicial + inventario_hoy.entradas - inventario_hoy.ventas
            inventario_hoy.save()
        else:
            InventarioDiario.objects.create(
                fecha=hoy,
                producto=producto,
                stock_inicial=nuevo_stock,
                entradas=0,
                ventas=0,
                stock_final=nuevo_stock,
            )
        
        messages.success(request, f'Stock de {producto.nombre} ajustado de {fmt_cantidad_unidad(stock_anterior, producto.unidad_medida)} a {fmt_cantidad_unidad(nuevo_stock, producto.unidad_medida)}.')
        return redirect('core:ajuste_inventario')
    
    productos = Producto.objects.filter(activo=True).order_by('categoria__nombre', 'nombre')
    ajustes = MovimientoInventario.objects.filter(tipo='ajuste').select_related('producto', 'usuario')[:50]

    return render(request, 'core/ajuste_inventario.html', {
        'productos': productos,
        'ajustes': ajustes,
    })


# ============================================================
# MOSTRADOR DEL CLIENTE (pantalla en tiempo real del POS)
# ============================================================
# Sin login ni token: /mostrador/ siempre funciona (TV del local).
# Sin websockets ni Redis: el POS empuja el carrito por POST y el
# mostrador lo lee por polling cada ~2.5 s. Funciona offline en LAN.

MOSTRADOR_PANTALLAS = [1, 2, 3, 4, 5]


def _mostrador_pantalla(request, data=None):
    try:
        pantalla = int((data or {}).get('pantalla', request.GET.get('pantalla', '1')))
    except (TypeError, ValueError):
        pantalla = 1
    return pantalla if pantalla in MOSTRADOR_PANTALLAS else 1


def mostrador_display(request):
    """Pantalla pública del cliente (TV). Siempre activa, sin login."""
    return render(request, 'core/mostrador.html', {
        'pantalla': _mostrador_pantalla(request),
    })


def mostrador_estado(request):
    """JSON que el mostrador consulta por polling. Público."""
    pantalla = _mostrador_pantalla(request)
    est = MostradorEstado.objects.filter(pantalla=pantalla).first()
    if est is None:
        return JsonResponse({'items': [], 'total': '0.00', 'mensaje': 'vacio'})
    items = est.items()
    # Estado rancio (cajero dejó el carrito hace >15 min): mostrar vacío.
    from datetime import timedelta as _td
    if est.mensaje == 'activo' and (timezone.now() - est.actualizado) > _td(minutes=15):
        return JsonResponse({'items': [], 'total': '0.00', 'mensaje': 'vacio'})
    return JsonResponse({
        'items': items,
        'total': str(est.total),
        'mensaje': est.mensaje,
        'actualizado': est.actualizado.strftime('%H:%M:%S'),
    })


@login_required
@require_POST
def pos_mostrador_empujar(request):
    """El POS empuja el carrito actual para una pantalla (llamado en cada renderCart)."""
    try:
        data = json.loads(request.body)
    except Exception:
        return JsonResponse({'error': 'JSON inválido.'}, status=400)
    try:
        pantalla = int(data.get('pantalla', 1))
    except (TypeError, ValueError):
        pantalla = 1
    if pantalla not in MOSTRADOR_PANTALLAS:
        pantalla = 1
    items = data.get('items', [])
    if not isinstance(items, list):
        items = []
    # Saneizar: solo campos de exhibición, máx 50 líneas.
    limpios = []
    for it in items[:50]:
        if not isinstance(it, dict):
            continue
        try:
            limpios.append({
                'nombre': str(it.get('nombre', ''))[:120],
                'presentacion': str(it.get('presentacion', ''))[:80],
                'cantidad': str(it.get('cantidad', ''))[:20],
                'precio': str(it.get('precio', '0'))[:20],
                'subtotal': str(it.get('subtotal', '0'))[:20],
                'imagen': str(it.get('imagen', ''))[:500],
            })
        except Exception:
            continue
    try:
        total = Decimal(str(data.get('total', '0')))
    except Exception:
        total = Decimal('0')
    cajero = request.user.get_full_name() or request.user.username
    MostradorEstado.objects.update_or_create(
        pantalla=pantalla,
        defaults={'items_json': json.dumps(limpios), 'total': total,
                  'mensaje': 'activo' if limpios else 'vacio',
                  'cajero_nombre': cajero},
    )
    return JsonResponse({'success': True})


@login_required
@require_POST
def pos_mostrador_limpiar(request):
    """Avisa al mostrador: venta completada (muestra gracias) o carrito cancelado."""
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    try:
        pantalla = int(data.get('pantalla', 1))
    except (TypeError, ValueError):
        pantalla = 1
    if pantalla not in MOSTRADOR_PANTALLAS:
        pantalla = 1
    mensaje = data.get('mensaje', 'vacio')
    if mensaje not in ('vacio', 'completado'):
        mensaje = 'vacio'
    MostradorEstado.objects.update_or_create(
        pantalla=pantalla,
        defaults={'items_json': '[]', 'total': Decimal('0'), 'mensaje': mensaje,
                  'cajero_nombre': request.user.get_full_name() or request.user.username},
    )
    return JsonResponse({'success': True})


# ============================================================
# PANEL DEL VENDEDOR + ARQUEO DE TURNO + CONTEO CIEGO
# ============================================================

def _empleado_de(request):
    """Empleado del usuario actual o None."""
    try:
        return request.user.empleado
    except Empleado.DoesNotExist:
        return None


def _resumen_turno(turno):
    """Esperado del turno por método (ventas − gastos del turno).

    Efectivo esperado = Σ monto_recibido − Σ cambio − gastos en efectivo.
    Transferencia esperada = Σ monto_transferencia − gastos por transferencia.
    """
    agg = turno.ventas.filter(cancelada=False).aggregate(
        ef=Sum('monto_recibido'), tr=Sum('monto_transferencia'),
        cb=Sum('cambio'), tot=Sum('total'), n=Count('id'),
    )
    ef = (agg['ef'] or Decimal('0')) - (agg['cb'] or Decimal('0'))
    tr = agg['tr'] or Decimal('0')
    gagg = turno.gastos.aggregate(
        ef=Sum('cantidad_efectivo'), tr=Sum('cantidad_transferencia'))
    gef = gagg['ef'] or Decimal('0')
    gtr = gagg['tr'] or Decimal('0')
    return {
        'num_ventas': agg['n'] or 0,
        'total_ventas': agg['tot'] or Decimal('0'),
        'ventas_efectivo': ef,
        'ventas_transferencia': tr,
        'gastos_efectivo': gef,
        'gastos_transferencia': gtr,
        'esperado_efectivo': ef - gef,
        'esperado_transferencia': tr - gtr,
    }


@login_required
def mi_panel(request):
    """Panel del vendedor: ventas del día + accesos a arqueo y conteo.

    Los admin caen a su dashboard (el panel es para el vendedor).
    """
    try:
        if request.user.perfil.es_admin:
            return redirect('core:dashboard')
    except PerfilUsuario.DoesNotExist:
        return redirect('core:dashboard')
    empleado = _empleado_de(request)
    if empleado is None:
        messages.warning(request, 'Tu usuario no tiene ficha de empleado.')
        return redirect('core:pos')
    turno = empleado.turno_abierto
    hoy = ahora_servidor().date()
    ventas_hoy = Venta.objects.filter(
        cajero=request.user, fecha_venta__date=hoy, cancelada=False
    ).order_by('-fecha_venta')[:20]
    tot_hoy = Venta.objects.filter(
        cajero=request.user, fecha_venta__date=hoy, cancelada=False
    ).aggregate(t=Sum('total'), n=Count('id'))
    resumen = _resumen_turno(turno) if turno else None
    arqueo = getattr(turno, 'arqueo', None) if turno else None
    conteos = turno.conteos.all()[:10] if turno else []
    return render(request, 'core/mi_panel.html', {
        'empleado': empleado,
        'turno': turno,
        'resumen': resumen,
        'arqueo': arqueo,
        'conteos': conteos,
        'ventas_hoy': ventas_hoy,
        'total_hoy': tot_hoy['t'] or 0,
        'num_hoy': tot_hoy['n'] or 0,
    })


@login_required
def arqueo(request):
    """Arqueo del turno abierto en 2 pasos.

    Paso 1: fondo inicial + foto del esperado por método.
    Paso 2: el cajero declara lo contado (ayudante por denominaciones);
        se muestra faltante/sobrante en grande y se exige motivo si descuadra.
    """
    empleado = _empleado_de(request)
    if empleado is None:
        messages.warning(request, 'Tu usuario no tiene ficha de empleado.')
        return redirect('core:mi_panel')
    turno = empleado.turno_abierto
    if turno is None:
        messages.warning(request, 'No tienes turno abierto.')
        return redirect('core:mi_panel')
    resumen = _resumen_turno(turno)
    arqueo, _ = ArqueoTurno.objects.get_or_create(turno=turno)
    if arqueo.estado == 'confirmado':
        messages.info(request, 'Este arqueo ya fue confirmado.')
        return redirect('core:mi_panel')

    paso = request.GET.get('paso', '1')
    if arqueo.estado == 'declarado':
        # Ya declarado: mostrar resumen en espera de confirmación.
        return render(request, 'core/arqueo.html', {
            'empleado': empleado, 'turno': turno, 'resumen': resumen,
            'arqueo': arqueo, 'paso': 'espera',
            'denominaciones': DENOMINACIONES_CUP,
        })

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'fondo':
            try:
                fondo = Decimal(str(request.POST.get('fondo_inicial', '0') or '0'))
                if fondo < 0:
                    raise ValueError('El fondo no puede ser negativo.')
            except Exception:
                messages.error(request, 'Fondo inicial inválido.')
                fondo = None
            if fondo is not None:
                arqueo.fondo_inicial = fondo
                arqueo.esperado_efectivo = resumen['esperado_efectivo'] + fondo
                arqueo.esperado_transferencia = resumen['esperado_transferencia']
                arqueo.paso1_listo = True
                arqueo.save()
                messages.success(request, 'Paso 1 guardado. Ahora cuenta el efectivo.')
                return redirect('/arqueo/?paso=2')
        elif action == 'declarar':
            import json as _json
            detalle = {}
            total_ef = Decimal('0')
            for key, _lbl in DENOMINACIONES_CUP:
                try:
                    qty = int(request.POST.get('denom_' + key, '0') or '0')
                except (TypeError, ValueError):
                    qty = 0
                if qty < 0:
                    qty = 0
                if qty:
                    detalle[key] = qty
                    total_ef += DENOMINACIONES_CUP_VALOR[key] * qty
            try:
                cont_tr = Decimal(str(request.POST.get('contado_transferencia', '0') or '0'))
                if cont_tr < 0:
                    raise ValueError('negativo')
            except Exception:
                messages.error(request, 'Transferencia contada inválida.')
                return render(request, 'core/arqueo.html', {
                    'empleado': empleado, 'turno': turno, 'resumen': resumen,
                    'arqueo': arqueo, 'paso': '2',
                    'denominaciones': DENOMINACIONES_CUP,
                })
            observacion = (request.POST.get('observacion', '') or '').strip()
            # Foto fresca del esperado al declarar.
            arqueo.esperado_efectivo = resumen['esperado_efectivo'] + arqueo.fondo_inicial
            arqueo.esperado_transferencia = resumen['esperado_transferencia']
            arqueo.contado_efectivo = total_ef
            arqueo.contado_transferencia = cont_tr
            arqueo.detalle_json = _json.dumps(detalle)
            arqueo.observacion = observacion
            if arqueo.diferencia_total != 0 and not observacion:
                arqueo.save()
                messages.error(
                    request,
                    'Hay diferencia de $%.2f: escribe el motivo para poder declarar.'
                    % arqueo.diferencia_total)
                return render(request, 'core/arqueo.html', {
                    'empleado': empleado, 'turno': turno, 'resumen': resumen,
                    'arqueo': arqueo, 'paso': '2',
                    'denominaciones': DENOMINACIONES_CUP,
                })
            arqueo.estado = 'declarado'
            arqueo.declarado_por = request.user
            arqueo.declarado_at = timezone.now()
            arqueo.save()
            messages.success(request, 'Arqueo declarado. Queda en espera de confirmación del admin.')
            return redirect('core:mi_panel')

    if paso == '2':
        if not arqueo.paso1_listo:
            messages.warning(request, 'Primero completa el paso 1 (fondo inicial).')
            paso = '1'
    return render(request, 'core/arqueo.html', {
        'empleado': empleado, 'turno': turno, 'resumen': resumen,
        'arqueo': arqueo, 'paso': paso,
        'denominaciones': DENOMINACIONES_CUP,
    })


@requiere_admin
@require_POST
def arqueo_confirmar(request, pk):
    """El admin confirma el arqueo declarado ELIGIENDO qué hacer con la
    diferencia, y cierra el turno.

    Decisiones:
    - aceptar: se acepta la diferencia y se cierra (queda en el motivo).
    - gasto: el faltante se registra como gasto de caja (visible en IPB).
    - descontar: queda anotado como pendiente a descontar al empleado.
    - sobrante_caja: el sobrante queda en caja.
    """
    turno = get_object_or_404(Turno, pk=pk)
    arqueo = getattr(turno, 'arqueo', None)
    if arqueo is None or arqueo.estado != 'declarado':
        messages.warning(request, 'Ese turno no tiene arqueo declarado.')
        return redirect('core:empleado_turnos', pk=turno.empleado_id)
    decision = request.POST.get('decision', '')
    nota = (request.POST.get('decision_nota', '') or '').strip()
    validas = [c[0] for c in ArqueoTurno.DECISIONES if c[0]]
    if decision not in validas:
        messages.error(request, 'Elige qué hacer con la diferencia antes de confirmar.')
        return redirect('core:revisar_turno', pk=turno.pk)
    # Sin decisión en el físico tampoco se cierra (se revisa antes de
    # crear el gasto o confirmar, para no dejar medias tintas).
    bloqueos_fisico = _bloqueos_cierre_turno(turno, incluir_arqueo=False)
    if bloqueos_fisico:
        messages.error(request, 'No se puede cerrar: ' + ' '.join(bloqueos_fisico))
        return redirect('core:revisar_turno', pk=turno.pk)
    dif = arqueo.diferencia_total
    if decision == 'gasto':
        if dif >= 0:
            messages.error(request, 'Esa decisión es solo para faltante (diferencia negativa).')
            return redirect('core:revisar_turno', pk=turno.pk)
        monto = -dif
        Gasto.objects.create(
            numero_gasto=Gasto.generar_numero(),
            cajero=turno.empleado.user,
            turno=turno,
            cantidad_efectivo=monto,
            cantidad_transferencia=Decimal('0'),
            categoria='caja',
            descripcion=f'Faltante de caja · Arqueo turno #{turno.pk}' + (f' · {nota}' if nota else ''),
        )
    if decision == 'descontar' and not nota:
        messages.error(request, 'Si lo descuentas al empleado, anota el acuerdo en la nota.')
        return redirect('core:revisar_turno', pk=turno.pk)
    arqueo.decision = decision
    arqueo.decision_nota = nota
    arqueo.estado = 'confirmado'
    arqueo.confirmado_por = request.user
    arqueo.confirmado_at = timezone.now()
    arqueo.save()
    if turno.abierto:
        turno.cerrar()
    messages.success(
        request,
        'Arqueo confirmado (%s) y turno cerrado. Diferencia: $%.2f.'
        % (arqueo.get_decision_display(), dif))
    return redirect('core:empleado_turnos', pk=turno.empleado_id)


def _bloqueos_cierre_turno(turno, incluir_arqueo=True):
    """Motivos por los que el turno NO se puede cerrar todavía.

    Regla: sin decisión del admin en el dinero (arqueo) Y en el físico
    (conteos), el turno no se cierra.
    """
    motivos = []
    if incluir_arqueo:
        arqueo = getattr(turno, 'arqueo', None)
        if arqueo is None or arqueo.estado == 'borrador':
            motivos.append('Falta declarar el arqueo de caja.')
    conteos = list(turno.conteos.all())
    if not conteos:
        motivos.append('Falta entregar el conteo físico de productos.')
    else:
        if any(c.estado != 'cerrado' for c in conteos):
            motivos.append('Hay conteos físicos aún abiertos.')
        if any(c.estado == 'cerrado' and not c.decision for c in conteos):
            motivos.append('Hay conteos cerrados sin decisión del admin.')
    return motivos


@requiere_admin
@require_POST
def turno_cerrar(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    turno = empleado.turno_abierto
    if turno:
        # Cierre directo solo si TODO ya está decidido; si no, a Revisar.
        bloqueos = _bloqueos_cierre_turno(turno)
        arqueo = getattr(turno, 'arqueo', None)
        if bloqueos:
            messages.error(
                request,
                'No se puede cerrar: ' + ' '.join(bloqueos))
            return redirect('core:revisar_turno', pk=turno.pk)
        if arqueo is not None and arqueo.estado == 'declarado':
            # Ya pasó por Revisar con su decisión (sin bloqueos): confirmar.
            arqueo.estado = 'confirmado'
            if not arqueo.decision:
                arqueo.decision = 'aceptar'
            arqueo.confirmado_por = request.user
            arqueo.confirmado_at = timezone.now()
            arqueo.save()
            turno.cerrar()
            messages.success(
                request,
                'Arqueo declarado confirmado al cerrar. Diferencia: $%.2f. Ventas: %s - Total: $%s'
                % (arqueo.diferencia_total, turno.num_ventas, turno.total_ventas))
        else:
            turno.cerrar()
            messages.success(request, f'Turno cerrado para {empleado}. Ventas: {turno.num_ventas} - Total: ${turno.total_ventas}.')
    else:
        messages.warning(request, f'{empleado} no tiene turno abierto.')
    return redirect('core:empleado_lista')


def _conteo_permitido(request, conteo):
    """El conteo lo ve el dueño del turno o un admin."""
    try:
        if request.user.perfil.es_admin:
            return True
    except PerfilUsuario.DoesNotExist:
        return True
    return conteo.turno.empleado.user_id == request.user.id


@login_required
def conteo_lista(request):
    """Conteos ciegos del turno abierto + crear uno nuevo."""
    empleado = _empleado_de(request)
    try:
        es_admin = request.user.perfil.es_admin
    except PerfilUsuario.DoesNotExist:
        es_admin = True
    if empleado is None and not es_admin:
        messages.warning(request, 'Tu usuario no tiene ficha de empleado.')
        return redirect('core:mi_panel')
    turno = empleado.turno_abierto if empleado else None
    if turno is None and not es_admin:
        messages.warning(request, 'No tienes turno abierto.')
        return redirect('core:mi_panel')
    if request.method == 'POST' and turno is not None:
        if turno.conteos.filter(estado='abierto').exists():
            messages.warning(request, 'Ya tienes un conteo abierto en este turno.')
        else:
            conteo = ConteoCiego.objects.create(turno=turno, creado_por=request.user)
            messages.success(request, f'Conteo #{conteo.pk} iniciado. Anota sin mirar el sistema.')
            return redirect('core:conteo_contar', pk=conteo.pk)
    conteos = turno.conteos.all() if turno else ConteoCiego.objects.none()
    return render(request, 'core/conteo_lista.html', {
        'empleado': empleado, 'turno': turno, 'conteos': conteos,
    })


@login_required
def conteo_contar(request, pk):
    """Anotar cantidades A CIEGAS (la plantilla nunca muestra el stock)."""
    conteo = get_object_or_404(ConteoCiego, pk=pk)
    if not _conteo_permitido(request, conteo):
        messages.error(request, 'No tienes permiso para ver ese conteo.')
        return redirect('core:mi_panel')
    if conteo.estado != 'abierto':
        return redirect('core:conteo_comparar', pk=conteo.pk)
    productos = Producto.objects.filter(activo=True).select_related('categoria').order_by('categoria__nombre', 'nombre')
    categorias = Categoria.objects.filter(productos__activo=True).distinct().order_by('nombre')
    actuales = {l.producto_id: l.cantidad for l in conteo.lineas.all()}
    if request.method == 'POST':
        for p in productos:
            raw = request.POST.get('cant_%d' % p.pk, '')
            if raw is None or str(raw).strip() == '':
                continue
            try:
                from decimal import ROUND_HALF_UP as _RHU
                val = Decimal(str(raw).replace(',', '.'))
                if val < 0:
                    raise ValueError('negativo')
                if not p.permite_decimal:
                    val = val.to_integral_value(rounding=_RHU)
                else:
                    val = val.quantize(Decimal('0.001'))
            except Exception:
                messages.error(request, f'Cantidad inválida para {p.nombre}.')
                return render(request, 'core/conteo_contar.html', {
                    'conteo': conteo, 'productos': productos, 'actuales': actuales,
                    'categorias': categorias,
                })
            ConteoCiegoLinea.objects.update_or_create(
                conteo=conteo, producto=p, defaults={'cantidad': val})
        messages.success(request, 'Conteo guardado. Puedes seguir o cerrar para comparar.')
        return redirect('core:conteo_contar', pk=conteo.pk)
    return render(request, 'core/conteo_contar.html', {
        'conteo': conteo, 'productos': productos, 'actuales': actuales,
        'categorias': categorias,
    })


@login_required
@require_POST
def conteo_cerrar(request, pk):
    """Cierra el conteo y congela el stock del sistema por producto."""
    conteo = get_object_or_404(ConteoCiego, pk=pk)
    if not _conteo_permitido(request, conteo):
        messages.error(request, 'No tienes permiso para cerrar ese conteo.')
        return redirect('core:mi_panel')
    if conteo.estado != 'abierto':
        return redirect('core:conteo_comparar', pk=conteo.pk)
    # Productos sin línea quedan en 0 contado.
    vistos = set(conteo.lineas.values_list('producto_id', flat=True))
    for p in Producto.objects.filter(activo=True):
        linea, _ = ConteoCiegoLinea.objects.get_or_create(
            conteo=conteo, producto=p, defaults={'cantidad': Decimal('0')})
        linea.stock_sistema = p.stock
        linea.save(update_fields=['stock_sistema'])
    conteo.estado = 'cerrado'
    conteo.cerrado_por = request.user
    conteo.fecha_cierre = timezone.now()
    conteo.save()
    messages.success(
        request,
        f'Conteo #{conteo.pk} cerrado: {conteo.num_diferencias} producto(s) con diferencia.')
    return redirect('core:conteo_comparar', pk=conteo.pk)


@login_required
def conteo_comparar(request, pk):
    """Comparación producto por producto: sistema vs contado.

    Si el conteo sigue abierto, solo el admin puede espiarlo
    (el dueño debe cerrarlo primero para no romper lo "ciego").
    """
    conteo = get_object_or_404(
        ConteoCiego.objects.select_related('turno__empleado__user'), pk=pk)
    if not _conteo_permitido(request, conteo):
        messages.error(request, 'No tienes permiso para ver ese conteo.')
        return redirect('core:mi_panel')
    if conteo.estado != 'cerrado':
        try:
            es_admin = request.user.perfil.es_admin
        except PerfilUsuario.DoesNotExist:
            es_admin = True
        if not es_admin:
            messages.warning(request, 'Cierra el conteo para ver la comparación.')
            return redirect('core:conteo_contar', pk=conteo.pk)
    lineas = conteo.lineas.select_related('producto').order_by('producto__nombre')
    return render(request, 'core/conteo_comparar.html', {
        'conteo': conteo, 'lineas': lineas,
    })


# ============================================================
# REVISIÓN ADMIN: ARQUEOS + CONTEOS (qué hacer con las diferencias)
# ============================================================

@requiere_admin
def arqueos_admin(request):
    """Sección del admin: turnos abiertos con su arqueo/conteos (pendientes)
    e historial de turnos ya cerrados con su decisión."""
    abiertos = Turno.objects.filter(abierto=True).select_related(
        'empleado__user').prefetch_related('conteos', 'ventas').order_by('-fecha_apertura')
    pendientes = []
    for t in abiertos:
        pendientes.append({
            'turno': t,
            'resumen': _resumen_turno(t),
            'arqueo': getattr(t, 'arqueo', None),
            'conteos_abiertos': t.conteos.filter(estado='abierto').count(),
            'conteos_cerrados': t.conteos.filter(estado='cerrado'),
        })
    historial = Turno.objects.filter(abierto=False).select_related(
        'empleado__user').order_by('-fecha_cierre')[:20]
    return render(request, 'core/arqueos_admin.html', {
        'pendientes': pendientes,
        'historial': historial,
    })


@requiere_admin
def revisar_turno(request, pk):
    """Revisión conjunta del turno: dinero (arqueo) + físico (conteos).

    Aquí el admin ve lo declarado por el empleado, elige qué hacer con
    cada diferencia y confirma: eso cierra el turno.
    """
    turno = get_object_or_404(
        Turno.objects.select_related('empleado__user'), pk=pk)
    resumen = _resumen_turno(turno)
    arqueo = getattr(turno, 'arqueo', None)
    conteos = turno.conteos.prefetch_related('lineas__producto').all()
    bloqueos = _bloqueos_cierre_turno(turno) if turno.abierto else []
    bloqueos_fisico = _bloqueos_cierre_turno(turno, incluir_arqueo=False) if turno.abierto else []
    return render(request, 'core/revisar_turno.html', {
        'turno': turno,
        'empleado': turno.empleado,
        'resumen': resumen,
        'arqueo': arqueo,
        'conteos': conteos,
        'decisiones_arqueo': [c for c in ArqueoTurno.DECISIONES if c[0]],
        'bloqueos': bloqueos,
        'bloqueos_fisico': bloqueos_fisico,
    })


def _aplicar_ajuste_producto(producto, nuevo_stock, descripcion, usuario):
    """Lleva el stock del sistema a lo contado (criterio de FINAL).

    El conteo se hace al cierre sin más ventas: lo contado ES el stock
    final. Se mueve el vivo y la ficha de hoy mantiene su identidad
    (final = inicial + entradas − ventas) desplazando el inicial en la
    misma diferencia — igual que hace _sincronizar_inventario_dia, que
    ancla todo al stock vivo. Los días anteriores no se tocan.
    """
    stock_anterior = producto.stock
    diferencia = nuevo_stock - stock_anterior
    producto.stock = nuevo_stock
    producto.save()
    MovimientoInventario.objects.create(
        producto=producto,
        tipo='ajuste',
        cantidad=diferencia,
        stock_anterior=stock_anterior,
        stock_nuevo=nuevo_stock,
        descripcion=descripcion,
        usuario=usuario,
    )
    hoy = ahora_servidor().date()
    inv = InventarioDiario.objects.filter(fecha=hoy, producto=producto).first()
    if inv:
        inv.stock_final = nuevo_stock
        inv.stock_inicial = inv.stock_inicial + diferencia
        inv.save()
    else:
        InventarioDiario.objects.create(
            fecha=hoy, producto=producto, stock_inicial=nuevo_stock,
            entradas=0, ventas=0, stock_final=nuevo_stock)


@requiere_admin
@require_POST
def conteo_decidir(request, pk):
    """Decisión del admin sobre un conteo cerrado:

    - ajustar: el sistema se lleva a lo contado (movimientos de ajuste).
    - recontar: se reabre a ciegas para que el empleado cuente de nuevo.
    - aceptar: se deja constancia sin mover el stock.
    """
    conteo = get_object_or_404(
        ConteoCiego.objects.select_related('turno__empleado__user'), pk=pk)
    accion = request.POST.get('accion', '')
    nota = (request.POST.get('decision_nota', '') or '').strip()
    if accion not in ('ajustar', 'recontar', 'aceptar'):
        messages.error(request, 'Acción inválida.')
        return redirect('core:revisar_turno', pk=conteo.turno_id)
    if accion == 'ajustar':
        if conteo.estado != 'cerrado':
            messages.error(request, 'Solo se puede ajustar un conteo cerrado.')
            return redirect('core:revisar_turno', pk=conteo.turno_id)
        n = 0
        for l in conteo.lineas.select_related('producto').all():
            if l.diferencia not in (None, 0):
                _aplicar_ajuste_producto(
                    l.producto, l.cantidad,
                    f'Ajuste por conteo ciego #{conteo.pk} (contado {l.cantidad}, sistema {l.stock_sistema})',
                    request.user)
                n += 1
        conteo.decision = 'ajustado'
        conteo.decision_nota = nota
        conteo.decidido_por = request.user
        conteo.decidido_at = timezone.now()
        conteo.save()
        messages.success(request, f'Sistema llevado a lo contado en {n} producto(s).')
    elif accion == 'recontar':
        conteo.estado = 'abierto'
        conteo.fecha_cierre = None
        conteo.lineas.all().update(stock_sistema=None)
        conteo.decision = 'recontar'
        conteo.decision_nota = nota
        conteo.decidido_por = request.user
        conteo.decidido_at = timezone.now()
        conteo.save()
        messages.warning(request, f'Conteo #{conteo.pk} reabierto a ciegas para reconteo.')
    else:
        conteo.decision = 'aceptado'
        conteo.decision_nota = nota
        conteo.decidido_por = request.user
        conteo.decidido_at = timezone.now()
        conteo.save()
        messages.info(request, f'Conteo #{conteo.pk} aceptado sin mover el stock.')
    return redirect('core:revisar_turno', pk=conteo.turno_id)
